import json
import parameterlayer as parameter
import logging
import os
import boto3
from base64 import b64decode

logger = logging.getLogger()

parameter_store_encrypted = os.environ['parameter_store']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')

def dustyPageStatus(event, context):
    loggerLevel = parameter.get_parameter(parameter_store, 'loggerLevel')
    if (loggerLevel == 'ERROR'):
        logger.setLevel(logging.ERROR)
    elif (loggerLevel == 'INFO'):
        logger.setLevel(logging.INFO)
    elif (loggerLevel == 'DEBUG'):
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)

    response = ''
    res_list = []
    try:
        logger.info("inside dustyPage ")
        headerOrigin = parameter.get_parameter(parameter_store, 'Access-Control-Allow-Origin')

        request = json.loads(event['body'])
        logger.debug(request)
        client = boto3.client('cloudfront')
        appName = request['appName']
        for app in appName:
            getrsp = client.get_distribution_config(
                Id=parameter.get_parameter(parameter_store, app + '_distributionId'))
            logger.info(getrsp)
            TargetOriginId = str(getrsp['DistributionConfig']['DefaultCacheBehavior']['TargetOriginId'])
            configresp = client.get_distribution(Id=parameter.get_parameter(parameter_store, app + '_distributionId'))
            logger.info(configresp)
            Status = str(configresp['Distribution']['Status'])
            DustyPage = 'dusty'
            if Status == 'Deployed':
                if DustyPage in TargetOriginId:
                    tmp2 = ''
                    tmp2 = '{"appName": "'+app+'",'
                    tmp2 = tmp2 + '"dustyPageStatus": "ON"}'
                    res_list.append(tmp2)
                else:
                    tmp2 = ''
                    tmp2 = '{"appName": "'+app+'",'
                    tmp2 = tmp2 + '"dustyPageStatus": "OFF"}'
                    res_list.append(tmp2)
            else:
                tmp2 = ''
                tmp2 = '{"appName": "' + app + '",'
                tmp2 = tmp2 + '"dustyPageStatus": "' + Status + '"}'
                res_list.append(tmp2)
        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": 'Authorization',
                        "Access-Control-Allow-Origin": headerOrigin},
            "body": str(res_list)
        }
    except Exception as ex:
        respdata000 = {"statusCode": "6", "statusMessage": "System Error"}
        json_data000 = json.dumps(respdata000)

        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": 'Authorization',
                        "Access-Control-Allow-Origin": headerOrigin},
            "body": str(json.loads(json_data000))
        }

        logger.error("Error in getting response from rest API for dustyPage  " + str(ex))
    return response
    logger.info("End of dustyPage status check ")