import json
import requests
import boto3
import parameterlayer as parameter
import logging
import os
import urllib
from base64 import b64decode

logger = logging.getLogger()
letterIdforLog =""
CoverageIdforLog = ""

parameter_store_encrypted = os.environ['parameter_store']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')

def validateUser(event, context):
   loggerLevel = parameter.get_parameter(parameter_store,'loggerLevel')
   if (loggerLevel == 'ERROR'):
       logger.setLevel(logging.ERROR)
   elif (loggerLevel == 'INFO'):
       logger.setLevel(logging.INFO)
   elif (loggerLevel == 'DEBUG'):
       logger.setLevel(logging.DEBUG)
   else:
       logger.setLevel(logging.INFO)

   response = ""
   try:
        headerOrigin= parameter.get_parameter(parameter_store,'Access-Control-Allow-Origin')
        layer7_ip = parameter.get_parameter(parameter_store,'layer7_IP')
        url = 'https://'+layer7_ip+'/SecureGateway/InsuranceOnlineServices/PaymentService/validateCustomer'
        headers = {'Content-Type': 'application/json'}
        request = json.loads(json.dumps(event['body']))
        global letterIdforLog
        global CoverageIdforLog

        requestforLayer7 = json.loads(event['body'])
        logger.debug(request)

        letterIdforLog = str(requestforLayer7['letterId'])
        CoverageIdforLog = str(requestforLayer7['coverageId'])

        logger.info("inside validateUser  for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog)


        tmp2 = ''
        tmp2 = '{"firstName": "' + urllib.parse.quote_plus(str(requestforLayer7['firstName'])) + '",'
        tmp2 = tmp2 + '"lastName": "' + urllib.parse.quote_plus(str(requestforLayer7['lastName'])) + '",'
        tmp2 = tmp2 + '"coverageId": "' + str(requestforLayer7['coverageId']) + '",'
        tmp2 = tmp2 + '"regCoverageId": "' + str(requestforLayer7['regCoverageId']) + '",'
        tmp2 = tmp2 + '"letterId": "' + str(requestforLayer7['letterId']) + '",'
        tmp2 = tmp2 + '"letterType": "' + str(requestforLayer7['letterType']) + '",'
        tmp2 = tmp2 + '"signUp": "' + str(requestforLayer7['signUp']) + '"}}'

        rawResponse = requests.post(url, data=tmp2, headers=headers, auth=(parameter.get_parameter(parameter_store,'onlineservices_username'), parameter.get_parameter(parameter_store,'onlineservices_password')),verify='ssl/cacert.pem', timeout= parameter.get_parameter(parameter_store,'requests_timeout'))
        logger.debug(rawResponse)
        if (rawResponse.status_code == 500):
            respdata500 = {"statusCode": "6", "statusMessage": "System Error"}
            json_data500 = json.dumps(respdata500)
            response = {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Headers": 'Authorization', "Access-Control-Allow-Origin": headerOrigin},
                "body": str(json.loads(json_data500))
            }
            return response

        responseJson = json.loads(rawResponse.text)

        response = {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Headers": 'Authorization', "Access-Control-Allow-Origin": headerOrigin},
                "body": str(responseJson)
            }

   except Exception as ex:
       respdata000 = {"statusCode": "6", "statusMessage": "System Error"}
       json_data000 = json.dumps(respdata000)
       response = {
           "statusCode": 200,
           "headers": {"Access-Control-Allow-Headers": 'Authorization', "Access-Control-Allow-Origin": headerOrigin},
           "body": str(json.loads(json_data000))
       }
       logger.error ("Error in getting response from rest API for Validate User for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog + str(ex))
   logger.info("end of  validateUser method  for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog)
   return response


