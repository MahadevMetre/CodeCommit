import json
import json
import requests
import boto3
import datetime
import parameterlayer as parameter
import logging
import os
from base64 import b64decode

logger = logging.getLogger()
email = ""
CoverageIdforLog = ""
errorFlag = 0

parameter_store_encrypted = os.environ['parameter_store']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')


def postConfirmationupdateEmail (event, context):

    loggerLevel = parameter.get_parameter(parameter_store,'loggerLevel')
    if (loggerLevel == 'ERROR'):
        logger.setLevel(logging.ERROR)
    elif (loggerLevel == 'INFO'):
        logger.setLevel(logging.INFO)
    elif (loggerLevel == 'DEBUG'):
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)

    response = ''
    try:
        layer7_ip = parameter.get_parameter(parameter_store,'layer7_IP')
        headerOrigin = parameter.get_parameter(parameter_store,'Access-Control-Allow-Origin')
        url = 'https://' + layer7_ip + '/SecureGateway/InsuranceOnlineServices/PaymentService/updateEmailAddress'

        headers = {'Content-Type': 'application/json'}
        global email
        global CoverageIdforLog

        requestforLayer7 = json.loads(json.dumps(event['request']['userAttributes']))
        logger.debug(requestforLayer7)

        email = str(requestforLayer7['email'])
        CoverageIdforLog = str(requestforLayer7['custom:coverageId'])

        tmp2 = ''
        tmp2 = '{"userID": "PNARAYAN",'
        tmp2 = tmp2 + '"emailAddress": "' + str(requestforLayer7['email']) + '",'
        tmp2 = tmp2 + '"coverageId": "' + str(requestforLayer7['custom:coverageId']) + '"}'

        logger.info("inside updateEmailAddress for email " + email +" and Coverage ID "+ str(CoverageIdforLog))
        rawResponse = requests.post(url, data=tmp2, headers=headers, auth=(
        parameter.get_parameter(parameter_store,'onlineservices_username'), parameter.get_parameter(parameter_store,'onlineservices_password')),
                                    verify='ssl/cacert.pem', timeout=parameter.get_parameter(parameter_store,'requests_timeout'))
        responseJson = json.loads(rawResponse.text)
        if (rawResponse.status_code == 500):
            error_messages = {"EmailNotify": {
                "OnlinePayment": "Error in updating email details for mail ID  " + str(email)}}
            error_msg = json.dumps(error_messages)
            logger.error(error_msg)
            error_message = "System Error"
            logger.error(error_message)
            raise Exception(error_message)

        if (responseJson['status'] == 'SUCCESS'):
            return event
        else:
            global errorFlag
            errorFlag = 1
            error_message = responseJson['statusMessage']
            logger.error(error_message)
            raise Exception(error_message)





    except Exception as ex:
        if (errorFlag != 1):
            error_messages = {"EmailNotify": {
                "OnlinePayment": "Error in updating email details for mail ID  " + str(email)}}
            error_msg = json.dumps(error_messages)
            logger.error(error_msg)
        else:
            error_messages = {"EmailNotify": {
                "OnlinePayment": "Error in updating email details for mail ID  " + str(email)}}
            error_msg = json.dumps(error_messages)
            logger.error(error_msg)
    return event
    logger.info("end of  update Email Address for email " + email + " and Coverage ID " + str(CoverageIdforLog))