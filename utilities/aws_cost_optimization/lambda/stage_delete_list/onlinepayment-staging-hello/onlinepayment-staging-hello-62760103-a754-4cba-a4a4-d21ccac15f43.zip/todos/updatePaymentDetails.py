import json
import json
import requests
import boto3
import datetime
import parameterlayer as parameter
import logging
import os
import urllib
from base64 import b64decode

logger = logging.getLogger()
LastName = ""
CoverageIdforLog = ""

parameter_store_encrypted = os.environ['parameter_store']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')

def updatePaymentDetails (event, context):
    loggerLevel = parameter.get_parameter(parameter_store,'loggerLevel')
    if (loggerLevel == 'ERROR'):
        logger.setLevel(logging.ERROR)
    elif (loggerLevel == 'INFO'):
        logger.setLevel(logging.INFO)
    elif (loggerLevel == 'DEBUG'):
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)

    response = ''
    try:
        layer7_ip = parameter.get_parameter(parameter_store,'layer7_IP')
        headerOrigin = parameter.get_parameter(parameter_store,'Access-Control-Allow-Origin')
        url = 'https://' + layer7_ip + '/SecureGateway/InsuranceOnlineServices/SelfServicing/updatePaymentDetails'

        headers = {'Content-Type': 'application/json'}
        request = json.loads(json.dumps(event['body']))
        global LastName
        global CoverageIdforLog

        requestforLayer7 = json.loads(event['body'])
        logger.debug(request)

        LastName = str(requestforLayer7['lastName'])
        CoverageIdforLog = str(requestforLayer7['coverageID'])

        pReq ='{ "coverageID" : "'+ str(requestforLayer7['coverageID']) +'", '
        pReq = pReq + '"cardType" : "'+ str(requestforLayer7['cardType']) +'", '
        pReq = pReq + '"cardNumber" : "'+ str(requestforLayer7['cardNumber']) +'", '
        pReq = pReq + '"expiryDate" : "'+ str(requestforLayer7['expiryDate']) +'", '
        pReq = pReq + '"billingZipCode" : "'+ str(requestforLayer7['billingZipCode']) +'", '
        pReq = pReq + '"lastName" : "'+ urllib.parse.quote_plus(str(requestforLayer7['lastName'])) +'", '
        pReq = pReq + '"contactInfo" : { "address" : {"address1" : "'+ str(requestforLayer7["contactInfo"]["address"]["address1"]) +'", '
        pReq = pReq + ' "address2": "'+ str(requestforLayer7["contactInfo"]["address"]["address2"]) +'", '
        pReq = pReq + ' "city" : "' + str(requestforLayer7["contactInfo"]["address"]["city"]) +'", '
        pReq = pReq + ' "state" : "'+ str(requestforLayer7["contactInfo"]["address"]["state"]) +'", '
        pReq = pReq + ' "zip" : "'+ str(requestforLayer7["contactInfo"]["address"]["zip"]) +'" },'
        pReq = pReq + ' "emailAddress" : "'+ str(requestforLayer7["contactInfo"]['emailAddress']) +'" }}'

        logger.info("inside updatePaymentDetails for Last Name " + LastName +" and Coverage ID "+ CoverageIdforLog)
        rawResponse = requests.post(url, data=pReq, headers=headers, auth=(
        parameter.get_parameter(parameter_store,'onlineservices_username'), parameter.get_parameter(parameter_store,'onlineservices_password')),
                                    verify='ssl/cacert.pem', timeout=parameter.get_parameter(parameter_store,'requests_timeout'))
        if (rawResponse.status_code == 500):
            error_message = {"EmailNotify": {"OnlinePayment": "UpdatePaymentDetails call failed for Coverage ID " + CoverageIdforLog}}
            error_msg = json.dumps(error_message)
            logger.error(error_msg)
            respdata500 = {'status': {'status': 'FAILURE', 'statusDescription': 'System Error '}}
            json_data500 = json.dumps(respdata500)
            response = {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Headers": 'Authorization',
                            "Access-Control-Allow-Origin": headerOrigin},
                "body": str(json.loads(json_data500))
            }
            return response

        responseJson = json.loads(rawResponse.text)
        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": 'Authorization', "Access-Control-Allow-Origin": headerOrigin},
            "body": str(responseJson)
        }


    except Exception as ex:
        error_message = {"EmailNotify": {"OnlinePayment": "UpdatePaymentDetails call failed for Coverage ID " + CoverageIdforLog}}
        error_msg = json.dumps(error_message)
        logger.error(error_msg)
        respdata000 = {'status': {'status': 'FAILURE', 'statusDescription': 'System Error '}}
        json_data000 = json.dumps(respdata000)

        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": 'Authorization',
                        "Access-Control-Allow-Origin": headerOrigin},
            "body": str(json.loads(json_data000))
        }

        logger.error("Error in getting response from rest API for update PaymentDetails for Last Name " + LastName +" and Coverage ID "+ CoverageIdforLog + str(ex))

    return response