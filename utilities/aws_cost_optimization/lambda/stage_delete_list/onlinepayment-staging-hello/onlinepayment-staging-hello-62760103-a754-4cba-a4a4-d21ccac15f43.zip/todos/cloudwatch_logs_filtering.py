import gzip
import json
import base64
import boto3
import parameterlayer as parameter
import os
import logging
from base64 import b64decode
logger = logging.getLogger()

parameter_store_encrypted = os.environ['parameter_store']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')

stage_encrypted = os.environ['stage']
stage = boto3.client('kms').decrypt(CiphertextBlob=b64decode(stage_encrypted))['Plaintext'].decode('utf-8')


def cloudwatchTrigger(event, context):
    client = boto3.client('sns')


    loggerLevel = parameter.get_parameter(parameter_store, 'loggerLevel')
    if (loggerLevel == 'ERROR'):
        logger.setLevel(logging.ERROR)
    elif (loggerLevel == 'INFO'):
        logger.setLevel(logging.INFO)
    elif (loggerLevel == 'DEBUG'):
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)
    try:
        cw_data = event['awslogs']['data']
        compressed_payload = base64.b64decode(cw_data)
        uncompressed_payload = gzip.decompress(compressed_payload)
        payload = json.loads(uncompressed_payload)

        log_events = payload['logEvents']
        for log_event in log_events:
            logger.debug(log_event)
            error_message = log_event['message']
            logger.debug(error_message)
            if "OnlinePayment" in error_message:
                onlinepayment_sns_notify(client,parameter_store,error_message,stage)
            else:
                logger.info('Error is not related to OnlinePayment Failure')
    except Exception as ex:
        logger.error('Error in decrypting the events to get error message'+str(ex))

def onlinepayment_sns_notify(client,parameter_store,error_message,stage):
    try:
        onlinepayment_arn = parameter.get_parameter(parameter_store, 'sns_arn')
        logger.info("Inside OnlinePayment SNS notification")
        subject = "OnlinePayment Failure "+stage
        response = client.publish(TargetArn=onlinepayment_arn,Message= error_message,Subject=subject)

    except Exception as ex:
        logger.error('Error in sending SNS notification Message '+ error_message + ' Subject '+subject +' ' + str(ex))