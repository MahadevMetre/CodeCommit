import json
import parameterlayer as parameter
import logging
import os
import boto3
from base64 import b64decode

logger = logging.getLogger()

parameter_store_encrypted = os.environ['parameter_store']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')

def dustyPage(event, context):
    loggerLevel = parameter.get_parameter(parameter_store,'loggerLevel')
    if (loggerLevel == 'ERROR'):
        logger.setLevel(logging.ERROR)
    elif (loggerLevel == 'INFO'):
        logger.setLevel(logging.INFO)
    elif (loggerLevel == 'DEBUG'):
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)

    response = ''

    try:
        logger.info("inside dustyPage ")
        headerOrigin = parameter.get_parameter(parameter_store,'Access-Control-Allow-Origin')

        request = json.loads(event['body'])
        logger.debug(request)

        appName = str(request['appName'])
        switchFlag = str(request['switchFlag'])

        client = boto3.client('cloudfront')
        getrsp = client.get_distribution_config(Id = parameter.get_parameter(parameter_store,appName+'_distributionId'))
        logger.info(getrsp)
        if switchFlag == 'on':
            getrsp['DistributionConfig']['DefaultCacheBehavior']['TargetOriginId']=parameter.get_parameter(parameter_store,appName+'_dustyPage_originId')
        else:
            getrsp['DistributionConfig']['DefaultCacheBehavior']['TargetOriginId'] = parameter.get_parameter(parameter_store,appName+'_originId')

        logger.info(getrsp)
        updatersp = client.update_distribution(
            DistributionConfig=getrsp['DistributionConfig'],Id=parameter.get_parameter(parameter_store,appName+'_distributionId'),IfMatch=getrsp['ETag'])

        logger.info(updatersp)
        respdata = {"appName": appName, "switchFlag": switchFlag}
        json_data = json.dumps(respdata)
        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": 'Authorization',
                        "Access-Control-Allow-Origin": headerOrigin},
            "body": str(updatersp)
        }


    except Exception as ex:
        respdata000 = {"statusCode": "6", "statusMessage": "System Error"}
        json_data000 = json.dumps(respdata000)

        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": 'Authorization',
                        "Access-Control-Allow-Origin": headerOrigin},
            "body": str(json.loads(json_data000))
        }

        logger.error("Error in getting response from rest API for dustyPage  "  + str(ex))

        return response
    return response
    logger.info("End of dustyPage ")

