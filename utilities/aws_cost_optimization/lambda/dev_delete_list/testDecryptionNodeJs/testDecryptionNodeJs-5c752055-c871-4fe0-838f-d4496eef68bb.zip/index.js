
async function a(event){
    if (!decrypted) {
        // Decrypt code should run once and variables stored outside of the
        // function handler so that these are decrypted once per container
        const kms = new AWS.KMS();
        try {
            const req = { CiphertextBlob: Buffer.from(encrypted, 'base64') };
            const data = await kms.decrypt(req).promise();
            decrypted = data.Plaintext.toString('ascii');
            console.info('Decrypt error 1:', decrypted);
        } catch (err) {
            console.log('Decrypt error:', err);
            throw err;
        }
    }
    
    return decrypted;
    
};