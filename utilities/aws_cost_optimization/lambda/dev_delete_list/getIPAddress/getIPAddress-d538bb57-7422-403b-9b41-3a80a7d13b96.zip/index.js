    exports.handler = async (event, context, callback) => {
    console.log('SourceIP =', event['requestContext']['identity']['sourceIp']);
    const response = {
        statusCode: 200,
        body: JSON.stringify(event['requestContext']),
    };
    return response;
};