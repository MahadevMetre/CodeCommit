import json
import boto3
import os
from base64 import b64decode

parameter_store_encrypted = os.environ['envVar1']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps(parameter_store)
    }
