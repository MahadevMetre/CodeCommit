import json
import boto3
import logging
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    try:
        request = event["Records"][0]['Sns']['Message']
        req_replaced = request.replace("'",'"')
        req_json = json.loads(req_replaced)
        archiveId = req_json['ArchiveId']
        print (archiveId)
        dynamoclient = boto3.client('dynamodb')
        response = dynamoclient.update_item(
            TableName='glacier-object-logging-dev',
            Key={
                'archiveId': {"S": archiveId}
            },
            UpdateExpression="set retrievalStatus = :retrievalStatus",

            ExpressionAttributeValues={

                ':retrievalStatus': {"S": "READY TO DOWNLOAD"}
            }
        )
    except ClientError as e:
        logging.error(e)