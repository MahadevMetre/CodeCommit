import subprocess
import json
import logging
from datetime import datetime
import sys

stage_name = sys.argv[1]
aws_profile_name = sys.argv[2]
user_pool_id = sys.argv[3]
client_id = sys.argv[4]
security_group = sys.argv[5]
subnet_id = sys.argv[6]
vpc_id = sys.argv[7]
client_name = 'onlinepayment_cognito_appclient_'+stage_name

profile_setting = 'AWS_PROFILE='+aws_profile_name+'&&'
def log_errors(error_statement):
    curr_date = datetime.today().strftime('%Y-%m-%d')
    file_name = 'logs/customerpaychange_logs'+curr_date+'.log'
    logging.basicConfig(filename=file_name,level=logging.ERROR)
    logging.error(error_statement)

def code_deploy():
    try:
        serverless_execution_cmd = ['set',profile_setting,'serverless', 'deploy', '--stage', stage_name]
        serverless_execution_process = subprocess.Popen(serverless_execution_cmd, stderr=subprocess.PIPE,stdout=subprocess.PIPE, shell=True)
        serverless_execution_error = serverless_execution_process.stderr.readlines()
        serverless_execution_output = serverless_execution_process.communicate()[0]
        success_string = 'Stack update finished'
        if success_string in str(serverless_execution_output):
            if "errno" in str(serverless_execution_output):
                log_errors(serverless_execution_output)
                error = 'Error in deploying code. Check log files for more details'
                raise Exception(error)
            else:
                print (serverless_execution_output)
                print('Successfully deployed code')
                account_details()
        else:
            log_errors(serverless_execution_output)
            error = 'Error in deploying code. Check log files for more details'
            raise Exception(error)
    except Exception as ex:
        print(str(ex))

def account_details():
    try:
        account_details_command = ['set',profile_setting,'aws','sts','get-caller-identity']
        account_details_process = subprocess.Popen(account_details_command,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        account_details_error = account_details_process.stderr.readlines()
        account_details_output = account_details_process.communicate()[0]
        if account_details_error != []:
            log_errors(account_details_error)
            error = 'Error in getting account details for the further process.Check log file for more details.'
            raise  Exception(error)
        else:
            account_details_json = json.loads(account_details_output)
            account_number = account_details_json['Account']
            print (account_number)
            private_api_creation(account_number)
    except Exception as ex:
        print (str(ex))

def private_api_creation(account_number):
    try:
        endpoint_config = '{\"types\":[\"PRIVATE\"]}'
        api_name = 'onlinepayment-emailConfirmation-'+stage_name
        api_process = subprocess.Popen(['set',profile_setting,'aws','apigateway','create-rest-api','--name',api_name,'--region','us-east-1','--endpoint-configuration',endpoint_config],stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        api_error = api_process.stderr.readlines()
        api_output = api_process.communicate()[0]
        print(api_output)
        if api_error != []:
            log_errors(api_error)
            error = 'error in creating private api for email confirmation . Check log file for more details'
            raise Exception(error)
        else:
            api_output_json = json.loads(api_output)
            api_id = api_output_json['id']
            print ('private API creation for email confirmation completed')
            endpoint_creation(account_number,api_id)
    except Exception as ex:
        print (str(ex))

def endpoint_creation(account_number,api_id):
    try:
        endpoint_process = subprocess.Popen(['set',profile_setting,'aws','ec2','create-vpc-endpoint','--vpc-id',vpc_id,'--vpc-endpoint-type','Interface','--service-name','com.amazonaws.us-east-1.execute-api','--subnet-id',subnet_id,'--security-group-id',security_group,'--region','us-east-1'],stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        endpoint_error = endpoint_process.stderr.readlines()
        endpoint_output = endpoint_process.communicate()[0]
        if endpoint_error != []:
            log_errors(endpoint_error)
            error = 'Error in creating vpc endpoint for private api. Check log files for more details.'
            raise Exception(error)
        else:
            endpoint_output_json = json.loads(endpoint_output)
            endpoint_id = endpoint_output_json['VpcEndpoint']['VpcEndpointId']
            print('VPC endpoint creation completed for prvivate api')
            policy_attachment(account_number,api_id,endpoint_id)
    except Exception as ex:
        print (str(ex))

def policy_attachment(account_number,api_id,endpoint_id):
    try:
        json_policy = "\'{\"Version\": \"2012-10-17\",\"Statement\": [{\"Effect\": \"Allow\",\"Principal\": \"*\",\"Action\": \"execute-api:Invoke\",\"Resource\":\"arn:aws:execute-api:us-east-1:"+account_number+":"+api_id+"/*\",\"Condition\": {\"StringEquals\": {\"aws:sourceVpce\": \""+endpoint_id+"\"}}}]}\'"
        resource_policy = 'op="replace",path="/policy",value='+json_policy
        resource_policy_cmd = ['set',profile_setting,'aws','apigateway','update-rest-api','--rest-api-id',api_id,'--patch-operations',resource_policy,'--region','us-east-1']
        resource_policy_process = subprocess.Popen(resource_policy_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        resource_policy_error = resource_policy_process.stderr.readlines()
        resource_policy_output = resource_policy_process.communicate()[0]
        if resource_policy_error!= []:
            log_errors(resource_policy_error)
            error = 'Error in attaching resource policy to private API. Check log files for more details.'
            raise  Exception(error)
        else:
            print(resource_policy_output)
            print('Sucessfully attached resource policy to private API')
            get_parent_id(account_number,api_id)
    except Exception as ex:
        print(str(ex))

def get_parent_id(account_number,api_id):
    try:
        parent_id_cmd = ['set',profile_setting,'aws','apigateway','get-resources','--rest-api-id',api_id,'--region','us-east-1']
        parent_id_process = subprocess.Popen(parent_id_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        parent_id_error = parent_id_process.stderr.readlines()
        parent_id_output = parent_id_process.communicate()[0]
        parent_id_output_json = json.loads(parent_id_output)
        parent_id = parent_id_output_json['items'][0]['id']
        if parent_id_error != []:
            log_errors(parent_id_error)
            error = 'Error in getting parent id for private API. Check log files for more details.'
            raise Exception (error)
        else:
            print (parent_id_output)
            print ("Successfully got the parent id of private API")
            resource_creation(account_number,api_id,parent_id)

    except Exception as ex:
        print(str(ex))

def resource_creation(account_number,api_id,parent_id):
    try:
        resource_crtn_cmd = ['set',profile_setting,'aws','apigateway','create-resource','--rest-api-id',api_id,'--parent-id',parent_id,'--path-part','emailconfirmation','--region','us-east-1']
        resource_crtn_process = subprocess.Popen(resource_crtn_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        resource_crtn_error = resource_crtn_process.stderr.readlines()
        resource_crtn_output = resource_crtn_process.communicate()[0]
        resource_id_output_json = json.loads(resource_crtn_output)
        resource_id = resource_id_output_json['id']
        if resource_crtn_error != []:
            log_errors(resource_crtn_error)
            error = 'Error in creating resource inside private API. Check log files for more details.'
            raise Exception(error)
        else:
            print (resource_crtn_output)
            print('Successfully created resources inside private API')
            method_creation(account_number,api_id,resource_id)
    except Exception as ex:
        print(str(ex))

def method_creation(account_number,api_id,resource_id):
    try:
        method_crtn_cmd = ['set',profile_setting,'aws','apigateway','put-method','--rest-api-id',api_id,'--resource-id',resource_id,'--http-method','POST','--authorization-type','NONE','--no-api-key-required','--request-parameters','method.request.header.custom-header=false','--region','us-east-1']
        method_crtn_process = subprocess.Popen(method_crtn_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        method_crtn_error = method_crtn_process.stderr.readlines()
        method_crtn_output = method_crtn_process.communicate()[0]
        if method_crtn_error != []:
            log_errors(method_crtn_error)
            error = 'Error in cresting method in private API. Check log files for more details.'
            raise Exception (error)
        else:
            print (method_crtn_output)
            print('Successfully created method in private API')
            method_integration(account_number,api_id,resource_id)
    except Exception as ex:
        print(str(ex))

def method_integration(account_number,api_id,resource_id):
    try:
        function_name = 'onlinepayment-emailConfirmation-'+stage_name
        uri = 'arn:aws:apigateway:us-east-1:lambda:path/2015-03-31/functions/arn:aws:lambda:us-east-1:'+account_number+':function:'+function_name+'/invocations'
        print (uri)
        method_integration_cmd = ['set',profile_setting,'aws','apigateway','put-integration','--rest-api-id',api_id,'--resource-id',resource_id,'--http-method','POST','--type','AWS_PROXY','--integration-http-method','POST','--uri',uri,'--region','us-east-1']
        method_integration_process = subprocess.Popen(method_integration_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        method_integration_error = method_integration_process.stderr.readlines()
        method_integration_output = method_integration_process.communicate()[0]
        if method_integration_error != []:
            log_errors(method_integration_error)
            error = 'Error in integrating lambda with private API post methof. Check log files for more details.'
            raise Exception(error)
        else:
            print(method_integration_output)
            print('Successfully integrated lambda with the api method.')
            lambda_permission(account_number,api_id)
    except Exception as ex:
        print(str(ex))

def lambda_permission(account_number,api_id):
    try:
        function_name = 'onlinepayment-emailConfirmation-'+stage_name
        api_arn = 'arn:aws:execute-api:us-east-1:'+account_number+':'+api_id+'/*'
        lambda_permission_cmd = ['set',profile_setting,'aws','lambda','add-permission','--function-name',function_name,'--statement-id','31','--action','lambda:InvokeFunction','--principal','apigateway.amazonaws.com','--source-arn',api_arn,'--region','us-east-1']
        lambda_permission_process = subprocess.Popen(lambda_permission_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        lambda_permission_error = lambda_permission_process.stderr.readlines()
        lambda_permission_output = lambda_permission_process.communicate()[0]
        if lambda_permission_error != []:
            log_errors(lambda_permission_error)
            error = 'Error in adding permission to lambda to invoke private API. Check log files for more details.'
            raise Exception(error)
        else:
            print(lambda_permission_output)
            print('Successfully updated lambda permission to invoke private api')
            api_deployment(account_number,api_id)
    except Exception as ex:
        print(str(ex))

def api_deployment(account_number,api_id):
    try:
        api_deployment_cmd = ['set',profile_setting,'aws','apigateway','create-deployment','--rest-api-id',api_id,'--stage-name',stage_name,'--description','API to send email notification on success payment','--region','us-east-1']
        api_deployment_process = subprocess.Popen(api_deployment_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        api_deployment_error = api_deployment_process.stderr.readlines()
        api_deployment_output = api_deployment_process.communicate()[0]
        if api_deployment_error != []:
            log_errors(api_deployment_error)
            error = 'Error in deploying private API. Check log files for more details.'
            raise  Exception(error)
        else:
            print(api_deployment_output)
            print('Succesfully deployed private API')
            cognito_trigger(account_number,api_id)
    except Exception as ex:
        print (str(ex))

def cognito_trigger(account_number,api_id):
    try:
        pre_signup_trigger = 'PreSignUp=arn:aws:lambda:us-east-1:'+account_number+':function:onlinepayment-preSignupverifyUser-'+stage_name
        post_confirmation_trigger = 'PostConfirmation=arn:aws:lambda:us-east-1:'+account_number+':function:onlinepayment-postConfirmationupdateEmail-'+stage_name
        lambda_trigger = pre_signup_trigger+','+post_confirmation_trigger
        cognito_update_cmd = ['set',profile_setting, 'aws', 'cognito-idp', 'update-user-pool','--user-pool-id', user_pool_id, '--lambda-config', lambda_trigger, '--policies','PasswordPolicy={MinimumLength=8,RequireUppercase=true,RequireLowercase=true,RequireNumbers=true,RequireSymbols=true,TemporaryPasswordValidityDays=90}','--auto-verified-attributes', 'email', '--mfa-configuration', 'OFF', '--region','us-east-1']
        cognito_update_process = subprocess.Popen(cognito_update_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        cognito_update_error = cognito_update_process.stderr.readlines()
        cognito_update_output = cognito_update_process.communicate()[0]
        if cognito_update_error != []:
            log_errors(cognito_update_error)
            error = 'Error in updating cognito with lambda trigger. Check log files for more details.'
            raise Exception(error)
        else:
            print(cognito_update_output)
            print('Successfully updated cognito with lambda triggers')
            presignup_lambda_permission(account_number,user_pool_id,api_id)
    except Exception as ex:
        print(str(ex))

def presignup_lambda_permission(account_number,user_pool_id,api_id):
    try:
        presignup_lambda = 'onlinepayment-preSignupverifyUser-'+stage_name
        cognito_arn = 'arn:aws:cognito-idp:us-east-1:'+account_number+':userpool/'+user_pool_id
        presignup_lambda_permission_cmd = ['set',profile_setting,'aws','lambda','add-permission','--function-name',presignup_lambda,'--statement-id','41','--action','lambda:InvokeFunction','--principal','cognito-idp.amazonaws.com','--source-arn',cognito_arn,'--region','us-east-1']
        presignup_lambda_permission_process = subprocess.Popen(presignup_lambda_permission_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        presignup_lambda_permission_error = presignup_lambda_permission_process.stderr.readlines()
        presignup_lambda_permission_output = presignup_lambda_permission_process.communicate()[0]
        if presignup_lambda_permission_error != []:
            log_errors(presignup_lambda_permission_error)
            error = 'Error in updating presignup lambda permissions. Check log files for more details'
            raise Exception(error)
        else:
            print(presignup_lambda_permission_output)
            print ('Successfully updated pre signup lambda permissions')
            postconfirm_lambda_permission(account_number,user_pool_id,cognito_arn,api_id)
    except Exception as ex:
        print(str(ex))

def postconfirm_lambda_permission(account_number,user_pool_id,cognito_arn,api_id):
    try:
        postconfirm_lambda = 'onlinepayment-postConfirmationupdateEmail-'+stage_name
        postconfirm_lambda_permission_cmd = ['set',profile_setting,'aws','lambda','add-permission','--function-name',postconfirm_lambda,'--statement-id','51','--action','lambda:InvokeFunction','--principal','cognito-idp.amazonaws.com','--source-arn',cognito_arn,'--region','us-east-1']
        postconfirm_lambda_permission_process = subprocess.Popen(postconfirm_lambda_permission_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        postconfirm_lambda_permission_error = postconfirm_lambda_permission_process.stderr.readlines()
        postconfirm_lambda_permission_output = postconfirm_lambda_permission_process.communicate()[0]
        if postconfirm_lambda_permission_error != []:
            log_errors(postconfirm_lambda_permission_error)
            error = 'Error in updating post confirm lambda permission. Check log files for more details.'
            raise Exception(error)
        else:
            print(postconfirm_lambda_permission_output)
            print('Successfully updated post confirm lambda permissions')
            cognito_add_attribute(account_number,user_pool_id,api_id)
    except Exception as ex:
        print(str(ex))

def cognito_add_attribute(account_number,user_pool_id,api_id):
    try:
        add_attribute_cmd = ['set',profile_setting,'aws','cognito-idp','add-custom-attributes','--user-pool-id',user_pool_id,'--custom-attributes','Name=letterType,AttributeDataType=String,Required=false,Mutable=True,StringAttributeConstraints={MinLength=1,MaxLength=10}','--region','us-east-1']
        add_attribute_process = subprocess.Popen(add_attribute_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        add_attribute_error = add_attribute_process.stderr.readlines()
        add_attribute_output = add_attribute_process.communicate()[0]
        if add_attribute_error != []:
            log_errors(add_attribute_error)
            error = 'Error in adding attribute to cognito user pool. Check log files for more details.'
            raise Exception(error)
        else:
            print(add_attribute_output)
            print('Successfully added attributes to cognito user pool')
            attribute_permission(account_number,user_pool_id,api_id)
    except Exception as ex:
        print(str(ex))

def attribute_permission(account_number,user_pool_id,api_id):
    try:
        attribute_prmsn_cmd = ['set',profile_setting,'aws','cognito-idp','update-user-pool-client','--user-pool-id',user_pool_id,'--client-id',client_id,'--client-name',client_name,'--write-attributes','email','given_name','family_name','custom:coverageId','custom:letterId','custom:letterType','--region','us-east-1']
        attribute_prmsn_process = subprocess.Popen(attribute_prmsn_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        attribute_prmsn_error = attribute_prmsn_process.stderr.readlines()
        attribute_prmsn_output = attribute_prmsn_process.communicate()[0]
        if attribute_prmsn_error != []:
            log_errors(attribute_prmsn_error)
            error = 'Error in adding letterType attribute to cognito user pool. Check log files for more details.'
            raise Exception(error)
        else:
            print(attribute_prmsn_output)
            print('Successfully added letterType attribute to cognito user pool.')
            filter_permission(account_number,api_id)
    except Exception as ex:
        print(str(ex))

def filter_permission(account_number,api_id):
    try:
        log_groups = ['updatePaymentDetails','postConfirmationupdateEmail','emailConfirmation']
        statement_id = 90
        for groups in log_groups:
            statement_id = statement_id+1
            function_name = 'onlinepayment-customizedSNS-'+stage_name
            log_group_name = '/aws/lambda/onlinepayment-'+groups+'-'+stage_name
            sns_lambda_arn ='arn:aws:lambda:us-east-1:'+account_number+':function:onlinepayment-customizedSNS-'+stage_name
            log_group_arn = 'arn:aws:logs:us-east-1:'+account_number+':log-group:'+log_group_name+':*'
            filter_permission_cmd = ['set',profile_setting, 'aws', 'lambda', 'add-permission','--function-name', function_name, '--statement-id',str(statement_id), '--principal','logs.us-east-1.amazonaws.com', '--action', 'lambda:InvokeFunction', '--source-arn',log_group_arn, '--source-account', account_number, '--region', 'us-east-1']
            filter_permission_process = subprocess.Popen(filter_permission_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
            filter_permission_error = filter_permission_process.stderr.readlines()
            filter_permission_output = filter_permission_process.communicate()[0]
            if filter_permission_error != []:
                log_errors(filter_permission_error)
                error = 'Error in adding filter permission to log group '+str(groups)+'.Check log files for more details.'
                raise Exception(error)
            else:
                print(filter_permission_output)
                print('Successfully added filter permission to log group '+groups)
        subscription_filter(account_number,api_id)
    except Exception as ex:
        print(str(ex))

def subscription_filter(account_number,api_id):
    try:
        log_groups = ['updatePaymentDetails','postConfirmationupdateEmail','emailConfirmation']
        for groups in log_groups:
            log_group_name = '/aws/lambda/onlinepayment-'+groups+'-'+stage_name
            sns_lambda_arn ='arn:aws:lambda:us-east-1:'+account_number+':function:onlinepayment-customizedSNS-'+stage_name
            filter_pattern = '{$.EmailNotify.OnlinePayment = "*"}'
            subscription_filter_cmd = ['set',profile_setting,'aws','logs','put-subscription-filter','--log-group-name',log_group_name,'--filter-name','ErrorNotification','--filter-pattern',filter_pattern,'--destination-arn',sns_lambda_arn,'--region','us-east-1']
            subscription_filter_process = subprocess.Popen(subscription_filter_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
            subscription_filter_error = subscription_filter_process.stderr.readlines()
            subscription_filter_output = subscription_filter_process.communicate()[0]
            if subscription_filter_error != []:
                log_errors(subscription_filter_error)
                error = 'Error in adding subscription filter to log group '+str(groups)+'.Check log files for more details.'
                raise Exception(error)
            else:
                print(subscription_filter_output)
                print('Successfully added subscription filter to log group '+groups)
                print (" OUTPUT: ")
                print ("API_ID: "+api_id)
    except Exception as ex:
        print(str(ex))


code_deploy()