import json
import requests
import boto3
import parameterlayer as parameter
import logging
import os
import urllib
from base64 import b64decode

logger = logging.getLogger()
letterIdforLog =""
CoverageIdforLog = ""
errorFlag = 0

parameter_store_encrypted = os.environ['parameter_store']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')

def preSignupverifyUser(event, context):
   loggerLevel = parameter.get_parameter(parameter_store,'loggerLevel')
   if (loggerLevel == 'ERROR'):
       logger.setLevel(logging.ERROR)
   elif (loggerLevel == 'INFO'):
       logger.setLevel(logging.INFO)
   elif (loggerLevel == 'DEBUG'):
       logger.setLevel(logging.DEBUG)
   else:
       logger.setLevel(logging.INFO)

   response = ""
   try:
        layer7_ip = parameter.get_parameter(parameter_store,'layer7_IP')
        url = 'https://'+layer7_ip+'/SecureGateway/InsuranceOnlineServices/PaymentService/validateCustomer'
        headers = {'Content-Type': 'application/json'}
        global letterIdforLog
        global CoverageIdforLog

        requestforLayer7 = json.loads(json.dumps(event['request']['userAttributes']))

        letterIdforLog = str(requestforLayer7['custom:letterId'])
        CoverageIdforLog = str(requestforLayer7['custom:coverageId'])

        logger.info("inside validateUser  for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog)



        tmp2 = ''
        tmp2 = '{"firstName": "' + urllib.parse.quote_plus(str(requestforLayer7['given_name'])) + '",'
        tmp2 = tmp2 + '"lastName": "' + urllib.parse.quote_plus(str(requestforLayer7['family_name'])) + '",'
        tmp2 = tmp2 + '"coverageId": "' + str(requestforLayer7['custom:coverageId']) + '",'
        tmp2 = tmp2 + '"regCoverageId": "' + str(requestforLayer7['custom:coverageId']) + '",'
        tmp2 = tmp2 + '"letterId": "' + str(requestforLayer7['custom:letterId']) + '",'
        tmp2 = tmp2 + '"letterType": "' + str(requestforLayer7['custom:letterType']) + '",'
        tmp2 = tmp2 + '"signUp": "True"}}'
        
        rawResponse = requests.post(url, data=tmp2, headers=headers, auth=(parameter.get_parameter(parameter_store,'onlineservices_username'), parameter.get_parameter(parameter_store,'onlineservices_password')),verify='ssl/cacert.pem', timeout= parameter.get_parameter(parameter_store,'requests_timeout'))
        logger.debug(rawResponse)
        responseJson = json.loads(rawResponse.text)
        if (rawResponse.status_code == 500):
            error_message = "System Error"
            raise Exception(error_message)

        if (responseJson['status'] == 'SUCCESS'):
            return event
        else:
            global errorFlag
            errorFlag = 1
            error_message = responseJson['statusMessage']
            raise Exception(error_message)





   except Exception as ex:
       if(errorFlag !=1):
         respdata000 = "System Error"
       else:
         respdata000=str(ex)
       raise Exception (respdata000)
       return  None
   logger.info("end of  validateUser method  for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog)


