import json
import requests
import xmltodict
import boto3
from json import loads
import datetime
import parameterlayer as parameter
import logging
import subprocess
from multiprocessing import Process
import os
from base64 import b64decode


logger = logging.getLogger()
letterIdforLog = ""
CoverageIdforLog = ""

orderIdGlobal=''
updatedDateTimeGlobal =''
angularStatusCode =''
angularStatusMessage =''

parameter_store_encrypted = os.environ['parameter_store']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')


#---------------Main program execution -------------------------------------
def processPayment(event, context):
    loggerLevel = parameter.get_parameter(parameter_store,'loggerLevel')
    if (loggerLevel == 'ERROR'):
        logger.setLevel(logging.ERROR)
    elif (loggerLevel == 'INFO'):
        logger.setLevel(logging.INFO)
    elif (loggerLevel == 'DEBUG'):
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)

    response = ''
    try:
        logger.debug('the input from UI is '+str(event))
        headerOrigin = parameter.get_parameter(parameter_store,'Access-Control-Allow-Origin')
        url = parameter.get_parameter(parameter_store,'Vantiv_api_URL')
        headers = {'Content-Type': 'application/xml'}
        request = json.loads(event['body'])
        global letterIdforLog
        global CoverageIdforLog

        requestforLayer7 = json.loads(event['body'])
        logger.debug(request)

        letterIdforLog = str(requestforLayer7['letterId'])
        CoverageIdforLog = str(requestforLayer7['coverageId'])
        logger.info("inside processPayment for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog)
        # generate the XML request
        inputXMLString = getInputinXML(parameter_store,request)
        logger.debug("Input to vantiv")
        logger.debug(inputXMLString)

        # check dynamo Db for approved payment for same letter id and coverage id
        alreadyMadePaymentCount = checkAlreadyMadePayment(parameter_store,request)
        logger.debug(alreadyMadePaymentCount)
        if (alreadyMadePaymentCount > 0):
            respdata7 = {"angularStatusMessage": "Premium Period is already paid", "angularStatusCode": "7"}
            json_data7 = json.dumps(respdata7)
            response = {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Headers": 'Authorization',
                            "Access-Control-Allow-Origin": headerOrigin},
                "body": json_data7

            }
            return response

        #check for the retry count
        retryCount = checkRetryCount(parameter_store,request)
        logger.debug (retryCount)
        if(retryCount >=5):
            respdata5 = {"angularStatusMessage": "Retry count exceeds 5", "angularStatusCode": "5"}
            json_data5 = json.dumps(respdata5)
            response = {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Headers": 'Authorization', "Access-Control-Allow-Origin": headerOrigin},
                "body": json_data5

            }
            return response

        # update dynamo DB with transaction details before request
        recordCreationStatus = createTransactionRecord(parameter_store,request, 'I', 'Initiated')
        if recordCreationStatus == "1":
            respdata1 = {"angularStatusMessage": "System Error", "angularStatusCode": "1"}
            json_data1 = json.dumps(respdata1)
            response = {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Headers": 'Authorization', "Access-Control-Allow-Origin": headerOrigin},
                "body": json_data1
            }
            return response

        rawXMLResponse = requests.post(url, data=inputXMLString, headers=headers, verify='ssl/cacert.pem', timeout= parameter.get_parameter(parameter_store,'Vantiv_api_timeout'))
        logger.info("Status code from vantiv for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog + " : "+str(rawXMLResponse.status_code))
        logger.debug(rawXMLResponse.text)
        if(rawXMLResponse.status_code == 200):
            responseJson = xmltodict.parse(str(rawXMLResponse.text))
        else:
            responseJson = rawXMLResponse.text

        #update dynamo DB with transaction

        updateTransactionRecordCount=  updateTransactionRecord(parameter_store,request, responseJson,rawXMLResponse.status_code )
        if updateTransactionRecordCount == "1":
            logger.error ("Error in updating dynamo db record in Backend for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog)



        respdata000 = {"angularStatusMessage": angularStatusMessage,"angularStatusCode":angularStatusCode }
        json_data000 = json.dumps(respdata000)

        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": 'Authorization', "Access-Control-Allow-Origin": headerOrigin},
            "body": json_data000
        }
    except Exception as ex:
        error_message = { "EmailNotify" : { "OnlinePayment" :"Exception in Vantiv Payment for Letter ID " + letterIdforLog +" and CoverageID "+ CoverageIdforLog + str(ex) }}
        error_msg = json.dumps(error_message)
        logger.error(error_msg)

        respdata3 = {"angularStatusMessage": "System Error", "angularStatusCode": "3"}
        json_data3 = json.dumps(respdata3)
        logger.error ("Error in  from Vantiv API Payment method for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog + str(ex))
        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": 'Authorization', "Access-Control-Allow-Origin": headerOrigin},
            "body": json_data3


        }
    logger.info("end of  processPayment for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog)
    return response

def getInputinXML(parameter_store,jsonObject):
    logger.info("Inside getInputinXML for Letter ID " + str(jsonObject['letterId']) +" and Coverage ID "+ str(jsonObject['coverageId']))
    current_time = datetime.datetime.now()
    global updatedDateTimeGlobal
    global orderIdGlobal


    orderIdGlobal = jsonObject['coverageId']+jsonObject['letterId']+current_time.strftime('%d%m%y')
    updatedDateTimeGlobal = datetime.datetime.now().isoformat()
    premiumDue_decimal= jsonObject['premiumDue']
    premiumDue = premiumDue_decimal.replace(".","")
    logger.debug ("updatedDateTimeGlobal in getInputinXML"+updatedDateTimeGlobal)

    xmlReq = '<litleOnlineRequest version="9.9" xmlns="http://www.litle.com/schema" merchantId="'+parameter.get_parameter(parameter_store,'merchantId')+'">'
    xmlReq = xmlReq + '<authentication>'
    xmlReq = xmlReq + '<user>' + parameter.get_parameter(parameter_store,'vantiv_username') + '</user>'
    xmlReq = xmlReq + '<password>' + parameter.get_parameter(parameter_store,'vantiv_password') + '</password>'
    xmlReq = xmlReq + '</authentication>'
    xmlReq = xmlReq + '<sale id="'+jsonObject['letterId']+'" reportGroup="'+jsonObject['reportGroup']+'" customerId="'+jsonObject['coverageId']+'">'
    xmlReq = xmlReq + '<orderId>'+orderIdGlobal+'</orderId>'
    xmlReq = xmlReq + '<amount>'+premiumDue+'</amount>'
    xmlReq = xmlReq + '<orderSource>'+jsonObject['orderSource']+'</orderSource>'
    xmlReq = xmlReq + '<billToAddress>'
    xmlReq = xmlReq + '<name>'+jsonObject['cardholdername']+'</name>'
    xmlReq = xmlReq + '<addressLine1>'+jsonObject['addressLine1']+'</addressLine1>'
    xmlReq = xmlReq + '<addressLine2>' + jsonObject['addressLine2'] + '</addressLine2>'
    xmlReq = xmlReq + '<addressLine3>' + jsonObject['addressLine3'] + '</addressLine3>'
    xmlReq = xmlReq + '<state>'+jsonObject['state']+'</state>'
    xmlReq = xmlReq + '<city>' + jsonObject['city'] + '</city>'
    xmlReq = xmlReq + '<zip>'+jsonObject['zip']+'</zip>'
    xmlReq = xmlReq + '<email>'+jsonObject['email']+'</email>'
    xmlReq = xmlReq + '</billToAddress>'
    xmlReq = xmlReq + '<card>'
    xmlReq = xmlReq + '<type>'+jsonObject['cardType']+'</type>'
    xmlReq = xmlReq + '<number>'+jsonObject['cardNumber']+'</number>'
    xmlReq = xmlReq + '<expDate>'+jsonObject['expDate']+'</expDate>'
    xmlReq = xmlReq + '<cardValidationNum>'+jsonObject['cardValidationNum']+'</cardValidationNum>'
    xmlReq = xmlReq + '</card>'
    xmlReq = xmlReq + '</sale>'
    xmlReq = xmlReq + '</litleOnlineRequest>'
    logger.info("End of getInputinXML  for Letter ID " + str(jsonObject['letterId']) +" and Coverage ID "+ str(jsonObject['coverageId']))
    return xmlReq

def checkRetryCount(parameter_store,jsonObject):
    logger.info("Inside checkRetryCount  for Letter ID " + str(jsonObject['letterId']) +" and Coverage ID "+ str(jsonObject['coverageId']))
    dynamoclient = boto3.client('dynamodb')
    success_count =0
    startDate = (datetime.datetime.now() -  datetime.timedelta(minutes=60)).isoformat()
    endDate = datetime.datetime.now().isoformat()

    try:
        dynamo_response = dynamoclient.query(TableName=parameter.get_parameter(parameter_store,'dynamodb_transactionTable'),
                                             KeyConditionExpression='BILLING_ID = :billingId ',
                                             FilterExpression="STATUS_CODE <> :statusCode AND LETTER_ID = :letterId AND COVERAGE_ID = :coverageId AND UPDATED_DATE_TIME BETWEEN :sdate AND :edate ",
                                             ExpressionAttributeValues={":billingId": {"S": jsonObject['billigId']},
                                                                        ":sdate" : {"S" : startDate},
                                                                        ":edate": {"S": endDate},
                                                                        ":letterId": {"S": jsonObject['letterId']},
                                                                        ":coverageId": {"S": jsonObject['coverageId']},
                                                                        ":statusCode" :{"S" :"A"}
                                                                        }
                                             )
        logger.debug(dynamo_response)
        success_count = dynamo_response['Count']
    except Exception as ex:
        logger.error("Error in  checkRetryCount from DynamoDB  for user :  " +str(jsonObject['usernameLoggedIn'])+" for Letter ID " + str(jsonObject['letterId']) +" and Coverage ID "+ str(jsonObject['coverageId'])+ str(ex))
    logger.info("End of checkRetryCount  for Letter ID " + str(jsonObject['letterId']) +" and Coverage ID "+ str(jsonObject['coverageId']))
    return success_count

def checkAlreadyMadePayment(parameter_store,jsonObject):
    logger.info("Inside checkAlreadyMadePayment for letterID "+ str(jsonObject['letterId']) +" and coverageID "+ str(jsonObject['coverageId']))
    dynamoclient = boto3.client('dynamodb')
    success_count =0


    try:
        dynamo_response = dynamoclient.query(TableName=parameter.get_parameter(parameter_store,'dynamodb_transactionTable'),
                                             KeyConditionExpression='BILLING_ID = :id ',
                                             FilterExpression='STATUS_CODE = :sa AND LETTER_ID = :l AND COVERAGE_ID = :c',
                                             ExpressionAttributeValues={":id": {"S": jsonObject['billigId']},
                                                                        ":sa": {"S": "A"},
                                                                        ":l": {"S": jsonObject['letterId']},
                                                                        ":c": {"S": jsonObject['coverageId']}})

        logger.debug(dynamo_response)
        success_count = dynamo_response['Count']
    except Exception as ex:
        logger.error("Error in  checkAlreadyMadePayment for letterID "+ str(jsonObject['letterId']) +" and coverageID "+ str(jsonObject['coverageId'])+str(ex))
    logger.info("End of checkAlreadyMadePayment for letterID "+ jsonObject['letterId'] +" and coverageID "+ jsonObject['coverageId'])
    return success_count



def createTransactionRecord(parameter_store,jsonObject,STATUS_CODE,STATUSMESSAGE):
    logger.info("Inside createTransactionRecord  for Letter ID " + str(jsonObject['letterId']) +" and Coverage ID "+ str(jsonObject['coverageId']))
    response ='0'

    ttl = str(int(((datetime.datetime.now() + datetime.timedelta(days=parameter.get_parameter(parameter_store,"TTLValue"))) - (
        datetime.datetime.utcfromtimestamp(0))).total_seconds() * 1000.0))

    try:
        dynamoclient = boto3.client('dynamodb')
        response = dynamoclient.put_item(TableName = parameter.get_parameter(parameter_store,'dynamodb_transactionTable'),
            Item={"BILLING_ID":{"S":jsonObject['billigId']},
                  "LETTER_ID":{"S":jsonObject['letterId']},
                  "COVERAGE_ID":{"S":jsonObject['coverageId']},
                  "CARDNUMBER":{"S":jsonObject['cardNumber'][-4:]},
                  "STATUS_CODE":{"S":STATUS_CODE},
                  "STATUSMESSAGE":{"S":STATUSMESSAGE},
                  "ORDERID":{"S":orderIdGlobal},
                  "CREATED_DATE_TIME":{"S":updatedDateTimeGlobal},
                  "UPDATED_DATE_TIME":{"S":updatedDateTimeGlobal},
                  "TTL": {"S": ttl}
            }
        )
    except Exception as ex:
        error_message = { "EmailNotify" : { "OnlinePayment" :"Create Dynamodb Record Failed for LetterID " + str(jsonObject['letterId']) +" and CoverageID "+ str(jsonObject['coverageId'])+" for the table " + parameter.get_parameter(parameter_store,
            'dynamodb_transactionTable')}}
        error_msg = json.dumps(error_message)
        logger.error(error_msg)
        logger.error("Error in saving transaction to"+ parameter.get_parameter(parameter_store,'dynamodb_transactionTable') +"for user " +str(jsonObject['usernameLoggedIn'])+" for Letter ID " + str(jsonObject['letterId']) +" and Coverage ID "+ str(jsonObject['coverageId'])+ str(ex))
        response =  "1"
        return response
    logger.info("End of createTransactionRecord  for Letter ID " + str(jsonObject['letterId']) +" and Coverage ID "+ str(jsonObject['coverageId']))
    return response

def updateTransactionRecord(parameter_store,jsonRequestObject,jsonResponse , VantivAPIResp):
    logger.info("Inside updateTransactionRecord  for Letter ID " + str(jsonRequestObject['letterId']) +" and Coverage ID "+ str(jsonRequestObject['coverageId']))
    response = '0'
    jsonResponse1 = json.dumps(jsonResponse)
    jsonResponseObject = json.loads(jsonResponse1)


    global angularStatusCode
    global angularStatusMessage
    response =''
    ddstatusCode = ''
    ddstatusMesage =''
    angularStatusCode=''
    angularStatusMessage=''

    if 'litleOnlineResponse' in jsonResponseObject:
        if 'saleResponse' in jsonResponseObject['litleOnlineResponse']:
            if 'response' in jsonResponseObject['litleOnlineResponse']['saleResponse']:
                angularStatusCode = jsonResponseObject['litleOnlineResponse']['saleResponse']['response']
    if 'litleOnlineResponse' in jsonResponseObject:
        if 'saleResponse' in jsonResponseObject['litleOnlineResponse']:
            if 'message' in jsonResponseObject['litleOnlineResponse']['saleResponse']:
                angularStatusMessage = jsonResponseObject['litleOnlineResponse']['saleResponse']['message']

    logger.debug("VantivAPIResp"+str(VantivAPIResp))

    if ( VantivAPIResp != 200):
        logger.debug("VantivAPIResp !=200")
        ddstatusCode = 'E'
        angularStatusCode = 'E'
        angularStatusMessage = 'System Error'
        ddstatusMesage= 'Call to backend failed'
    elif ( jsonResponseObject['litleOnlineResponse']['saleResponse']['orderId'] != orderIdGlobal):
        logger.debug("order id in request and response is not matching")
        ddstatusCode = 'E'
        angularStatusCode = 'E'
        angularStatusMessage = 'OrderId in request and response is not equal'
        ddstatusMesage= 'OrderId in request and response is not equal'
    else:
        if (jsonResponseObject['litleOnlineResponse']['saleResponse']['response'] =='000'):
            logger.debug("inside Status code A")
            ddstatusCode = 'A'
            angularStatusMessage = 'Payment accepted.Please allow 24 hours for status to update'
            angularStatusCode = jsonResponseObject['litleOnlineResponse']['saleResponse']['response']
            ddstatusMesage = jsonResponseObject['litleOnlineResponse']['saleResponse']['message']
            try:
                email_notification(parameter_store,jsonRequestObject)
            except Exception as e:
                logger.debug('Error in sending mail to customer because '+str(e))
                logger.error('Error in sending mail to customer')
            try:
                p = subprocess.Popen([updateBillHistory(parameter_store,jsonRequestObject)], stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE)
                result = p.stdout.readlines()
            except Exception as e:
                logger.error("exception in updateTransactionRecord" + str(e))

            logger.debug("after Async update bill history call")

        else:
            logger.debug("else")
            ddstatusCode = 'F'
            ddstatusMesage = jsonResponseObject['litleOnlineResponse']['saleResponse']['message']
    try:
        litleAuthCodeforDB = " "

        if 'litleOnlineResponse' in jsonResponseObject:
            if 'saleResponse' in jsonResponseObject['litleOnlineResponse']:
                if 'authCode' in jsonResponseObject['litleOnlineResponse']['saleResponse']:
                    litleAuthCodeforDB = jsonResponseObject['litleOnlineResponse']['saleResponse']['authCode']

        litleTxnIdforDB = " "

        if 'litleOnlineResponse' in jsonResponseObject:
            if 'saleResponse' in jsonResponseObject['litleOnlineResponse']:
                if 'litleTxnId' in jsonResponseObject['litleOnlineResponse']['saleResponse']:
                    litleTxnIdforDB = jsonResponseObject['litleOnlineResponse']['saleResponse']['litleTxnId']
                    logger.info("Transaction ID from  vantiv for for Letter ID " + str(jsonRequestObject['letterId']) +" and Coverage ID "+ str(jsonRequestObject['coverageId']) + " : "+ litleTxnIdforDB)

        responseforDB = " "

        if 'litleOnlineResponse' in jsonResponseObject:
            if 'saleResponse' in jsonResponseObject['litleOnlineResponse']:
                if 'response' in jsonResponseObject['litleOnlineResponse']['saleResponse']:
                    responseforDB = jsonResponseObject['litleOnlineResponse']['saleResponse']['response']

        responseTimeforDB = " "

        if 'litleOnlineResponse' in jsonResponseObject:
            if 'saleResponse' in jsonResponseObject['litleOnlineResponse']:
                if 'responseTime' in jsonResponseObject['litleOnlineResponse']['saleResponse']:
                    responseTimeforDB = jsonResponseObject['litleOnlineResponse']['saleResponse']['responseTime']

        logger.debug(" little auth code" + litleAuthCodeforDB)

        dynamoclient = boto3.client('dynamodb')
        response = dynamoclient.update_item(
            TableName=parameter.get_parameter(parameter_store,'dynamodb_transactionTable'),
            Key={
                'BILLING_ID' : {"S":jsonRequestObject['billigId']},
                'CREATED_DATE_TIME' : {"S":updatedDateTimeGlobal}
            },
            UpdateExpression="set LITLETXNID = :littleTxnId ,STATUS_CODE = :statusCode , STATUSMESSAGE =:statusMessage , LITLERESPONSECODE = :litleResponseCode ,LITLERESPONSETIME = :litleResponseTime ,LITLEAUTHCODE = :litleAuthCode , UPDATED_DATE_TIME = :updatedDateTime",

            ExpressionAttributeValues={

                ':littleTxnId': {"S": litleTxnIdforDB},
                ':statusCode': {"S": ddstatusCode},
                ':statusMessage': {"S": ddstatusMesage},
                ':litleResponseCode': {"S": responseforDB},
                ':litleResponseTime': {"S": responseTimeforDB},
                ':litleAuthCode': {"S": litleAuthCodeforDB},
                ":updatedDateTime": {"S": datetime.datetime.now().isoformat()}
            }
        )

    except Exception as ex:
        error_message = {"EmailNotify": {"OnlinePayment": "Update DynamodbRecord Failed for LetterID " + str(jsonRequestObject['letterId']) +" and CoverageID "+ str(jsonRequestObject['coverageId'])+" for the table " + parameter.get_parameter(parameter_store,
            'dynamodb_transactionTable')}}
        error_msg = json.dumps(error_message)
        logger.error(error_msg)
        logger.error("Error in  updating transacion to DynamoDB for Letter ID " + str(jsonRequestObject['letterId']) +" and Coverage ID "+ str(jsonRequestObject['coverageId']) + str(ex))
        response = '1'
        return response
    logger.debug("response from update billing table")
    logger.debug(response)
    logger.info("End of updateTransactionRecord for Letter ID " + str(jsonRequestObject['letterId']) +" and Coverage ID "+ str(jsonRequestObject['coverageId']))
    return response


def updateBillHistory(parameter_store,jsonReqObject):

    logger.info ("inside update bill history for Letter ID " + str(jsonReqObject['letterId']) +" and Coverage ID "+ str(jsonReqObject['coverageId']))

    responseJson =''
    try:

        layer7_ip = parameter.get_parameter(parameter_store,'layer7_IP')
        url = 'https://'+layer7_ip+'/SecureGateway/InsuranceOnlineServices/PaymentService/updateBillingHistory'
        headers = {'Content-Type': 'application/json'}
        logger.debug (jsonReqObject)
        request = '{"billingDetailsVO":'
        request = request + '{"coverageId": "'+jsonReqObject['coverageId']+'",'
        request = request + '"letterId": "' + jsonReqObject['letterId'] + '",'
        request = request + '"billingId": "' + jsonReqObject['billigId'] + '",'
        request = request + '"premiumDueDate": "' + jsonReqObject['premiumDueDate'] + '",'
        request = request + '"premiumDue": "' + jsonReqObject['premiumDue'] + '",'
        request = request + '"premiumPeriod": "' + jsonReqObject['premiumPeriod'] + '"}}'

        rawResponse = requests.post(url, data=request, headers=headers,
                                    auth=(
                                        parameter.get_parameter(parameter_store,'onlineservices_username'), parameter.get_parameter(parameter_store,'onlineservices_password')), verify='ssl/cacert.pem',timeout= parameter.get_parameter(parameter_store,'requests_timeout'))
        logger.debug(rawResponse.text)
        responseJson = json.loads(rawResponse.text)

        logger.debug(responseJson)

    except Exception as ex:
        error_message = {"EmailNotify": {"OnlinePayment":"UpdateBillHistory call failed for user : " + str(jsonReqObject['usernameLoggedIn']) + "for Letter ID " + str(jsonReqObject['letterId']) +" and Coverage ID "+ str(jsonReqObject['coverageId'])}}
        error_msg = json.dumps(error_message)
        logger.error(error_msg)
        logger.error(
            "Error in hitting rest API for update Bill History for user : " + str(jsonReqObject['usernameLoggedIn']) + "for Letter ID " + str(jsonReqObject['letterId']) +" and Coverage ID "+ str(jsonReqObject['coverageId']) + str(ex))
    logger.info("end of updateBillHistory  for Letter ID " + str(jsonReqObject['letterId']) +" and Coverage ID "+ str(jsonReqObject['coverageId']))
    return responseJson

def email_notification(parameter_store,jsonObject):
    logger.info(
        "inside email notification for customer email " + str(jsonObject['email']))

    responseJson = ''
    try:

        email_notify_api = parameter.get_parameter(parameter_store, 'email_notify_api')
        url = email_notify_api
        headers = {'Content-Type': 'application/json'}
        logger.debug(jsonObject)
        tmp2 = ''
        tmp2 = '{"email": "' + str(jsonObject['email']) + '",'
        tmp2 = tmp2 + '"sender_email": "' + str(parameter.get_parameter(parameter_store, 'sender_email')) + '",'
        tmp2 = tmp2 + '"userName": "' + str(jsonObject['usernameLoggedIn']) + '",'
        tmp2 = tmp2 + '"Amount": "' + str(jsonObject['premiumDue']) + '",'
        tmp2 = tmp2 + '"effectiveDate": "' + str(jsonObject['effectiveDate']) + '",'
        tmp2 = tmp2 + '"coverageType": "' + str(jsonObject['coverageType']) + '",'
        tmp2 = tmp2 + '"billFreq": "' + str(jsonObject['billFreq']) + '",'
        tmp2 = tmp2 + '"coverageId": "' + str(jsonObject['coverageId']) + '",'
        tmp2 = tmp2 + '"app_name": "' + str(parameter.get_parameter(parameter_store, 'app_name')) + '"}'
        rawResponse = requests.post(url, data=tmp2, headers=headers,
                                    timeout=parameter.get_parameter(parameter_store, 'requests_timeout'))
        logger.debug(rawResponse.text)
        responseJson = rawResponse.text

        logger.debug(responseJson)

    except Exception as ex:
        error_message = {"EmailNotify": {"OnlinePayment": "Error in sending mail on success payment for user " +str(jsonObject['email'])}}
        error_msg = json.dumps(error_message)
        logger.error(error_msg)
        error_message = "Error in sending mail to customer on success payment" + str(ex)
        logger.error(error_message)
    logger.info("end of email notification for customer email " + str(jsonObject['email']))
    return responseJson

