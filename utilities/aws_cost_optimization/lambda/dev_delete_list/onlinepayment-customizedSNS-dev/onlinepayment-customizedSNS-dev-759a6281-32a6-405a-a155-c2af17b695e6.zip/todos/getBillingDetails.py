import json
import json
import requests
import boto3
import datetime
import parameterlayer as parameter
import logging
import os
from base64 import b64decode

logger = logging.getLogger()
letterIdforLog = ""
CoverageIdforLog = ""

parameter_store_encrypted = os.environ['parameter_store']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')



def getBillingDetails(event, context):

    loggerLevel = parameter.get_parameter(parameter_store,'loggerLevel')
    if (loggerLevel == 'ERROR'):
        logger.setLevel(logging.ERROR)
    elif (loggerLevel == 'INFO'):
        logger.setLevel(logging.INFO)
    elif (loggerLevel == 'DEBUG'):
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)

    response = ''
    dynamoclient = boto3.client('dynamodb')
    try:
        layer7_ip = parameter.get_parameter(parameter_store,'layer7_IP')
        headerOrigin = parameter.get_parameter(parameter_store,'Access-Control-Allow-Origin')
        url = 'https://' + layer7_ip + '/SecureGateway/InsuranceOnlineServices/PaymentService/getBillingDetails'

        headers = {'Content-Type': 'application/json'}
        request = json.loads(json.dumps(event['body']))
        global letterIdforLog
        global CoverageIdforLog

        requestforLayer7 = json.loads(event['body'])
        logger.debug(request)

        letterIdforLog = str(requestforLayer7['letterId'])
        CoverageIdforLog = str(requestforLayer7['coverageId'])

        logger.info("inside getBillingDetails for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog)
        rawResponse = requests.post(url, data=request, headers=headers, auth=(
        parameter.get_parameter(parameter_store,'onlineservices_username'), parameter.get_parameter(parameter_store,'onlineservices_password')),
                                    verify='ssl/cacert.pem', timeout=parameter.get_parameter(parameter_store,'requests_timeout'))
        if (rawResponse.status_code == 500):
            respdata500 = {"statusCode": "6", "statusMessage": "System Error"}
            json_data500 = json.dumps(respdata500)
            response = {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Headers": 'Authorization',
                            "Access-Control-Allow-Origin": headerOrigin},
                "body": str(json.loads(json_data500))
            }
            return response

        responseJson = json.loads(rawResponse.text)


    except Exception as ex:
        respdata000 = {"statusCode": "6", "statusMessage": "System Error"}
        json_data000 = json.dumps(respdata000)

        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": 'Authorization',
                        "Access-Control-Allow-Origin": headerOrigin},
            "body": str(json.loads(json_data000))
        }

        logger.error("Error in getting response from rest API for Validate User for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog + str(ex))

        return response

    statusCode = str(responseJson['statusCode'])
    statusMessage = str(responseJson['statusMessage'])

    if statusCode == '0':

        response = responseJson


    else:
        billingId = str(responseJson['billingVO']['billingId'])
        coverageId = str(responseJson['billingVO']['coverageId'])
        letterId = str(responseJson['billingVO']['letterId'])

        retryCount = checkRetryCount(parameter_store,billingId, coverageId, letterId)
        if (retryCount >= 5):
            responseJson['statusMessage'] = 'Retry count exceeds 5'
            responseJson['statusCode'] = 5
            response = {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Headers": 'Authorization',
                            "Access-Control-Allow-Origin": headerOrigin},
                "body": str(responseJson)
            }
            return response
        logger.debug(retryCount)

        try:
            dynamo_response = dynamoclient.query(TableName=parameter.get_parameter(parameter_store,'dynamodb_transactionTable'),
                                                 KeyConditionExpression='BILLING_ID = :id ',
                                                 FilterExpression='STATUS_CODE = :sa AND LETTER_ID = :l AND COVERAGE_ID = :c',
                                                 ExpressionAttributeValues={":id": {"S": billingId}, ":sa": {"S": "A"},
                                                                            ":l": {"S": letterId},
                                                                            ":c": {"S": coverageId}})
        except Exception as ex:
            logger.error("Error in  retrieving PDN details from DynamoDB for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog + str(ex))
            responseDB = {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Headers": 'Authorization',
                            "Access-Control-Allow-Origin": headerOrigin},
                "body": str(ex)
            }
            return responseDB
        success_count = dynamo_response['Count']
        logger.debug(success_count)

        if statusMessage == 'Received':
            logger.debug("Payment Received in as400!!!!!")
            responseJson['statusCode'] = 2
            responseJson['statusMessage'] = 'Premium Period is already paid'
            response = responseJson

        elif success_count != 0 and statusMessage == 'Pending':
            responseJson['statusCode'] = 3
            logger.debug("Payment Received  but not updated in As400!!!!!")
            responseJson['statusMessage'] = 'Premium Period is already paid'
            response = responseJson
        elif success_count == 0 and statusMessage == 'Pending':
            responseJson['statusCode'] = 1
            logger.debug("Proceed with Payment !!!!!")
            responseJson['statusMessage'] = 'Pending'
            response = responseJson

    exitResponse = {
        "statusCode": 200,
        "headers": {"Access-Control-Allow-Headers": 'Authorization',
                    "Access-Control-Allow-Origin": headerOrigin},
        "body": str(response)
    }
    logger.info("end of getBillingDetails for Letter ID " + letterIdforLog +" and Coverage ID "+ CoverageIdforLog)
    return exitResponse


def checkRetryCount(parameter_store,billingId, coverageId, letterId):
    logger.info("inside checkRetryCount for Letter ID " + letterId +" and Coverage ID "+ coverageId)
    dynamoclient = boto3.client('dynamodb')
    success_count = 0

    startDate = (datetime.datetime.now() - datetime.timedelta(minutes=60)).isoformat()
    endDate = datetime.datetime.now().isoformat()

    try:
        dynamo_response = dynamoclient.query(TableName=parameter.get_parameter(parameter_store,'dynamodb_transactionTable'),
                                             KeyConditionExpression='BILLING_ID = :billingId ',
                                             FilterExpression="STATUS_CODE <> :statusCode AND LETTER_ID = :letterId AND COVERAGE_ID = :coverageId  AND UPDATED_DATE_TIME BETWEEN :sdate AND :edate ",
                                             ExpressionAttributeValues={":billingId": {"S": billingId},
                                                                        ":sdate": {"S": startDate},
                                                                        ":edate": {"S": endDate},
                                                                        ":letterId": {"S": letterId},
                                                                        ":coverageId": {"S": coverageId},
                                                                        ":statusCode": {"S": "A"}
                                                                        }
                                             )
        logger.debug(dynamo_response)
        success_count = dynamo_response['Count']
    except Exception as ex:
        logger.error("Error in  checkRetryCount from DynamoDB for Letter ID " + letterId +" and Coverage ID "+ coverageId + str(ex))
    logger.info("end of checkRetryCount for Letter ID " + letterId +" and Coverage ID "+ coverageId)
    return success_count