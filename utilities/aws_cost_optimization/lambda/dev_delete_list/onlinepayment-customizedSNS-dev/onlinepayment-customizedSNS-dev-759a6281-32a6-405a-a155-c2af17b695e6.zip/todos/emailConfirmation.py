import json
import logging
import boto3
import os
from botocore.exceptions import ClientError
import parameterlayer as parameter
from base64 import b64decode

logger = logging.getLogger()
parameter_store_encrypted = os.environ['parameter_store']
parameter_store = boto3.client('kms').decrypt(CiphertextBlob=b64decode(parameter_store_encrypted))['Plaintext'].decode('utf-8')


def emailConfirmation(event, context):
    userNameloggedIn = ''

    loggerLevel = parameter.get_parameter(parameter_store, 'loggerLevel')
    if (loggerLevel == 'ERROR'):
        logger.setLevel(logging.ERROR)
    elif (loggerLevel == 'INFO'):
        logger.setLevel(logging.INFO)
    elif (loggerLevel == 'DEBUG'):
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)
    request = json.loads(event['body'])
    SENDER = request['sender_email']
    RECIPIENT = request['email']
    APP_NAME= request['app_name']
    userName = request['userName']
    userNameLower = userName.lower()
    nameList = userNameLower.split()
    for names in nameList:
        captailizedName = names.capitalize()
        if userNameloggedIn == '':
         userNameloggedIn = userNameloggedIn+captailizedName
        else:
            userNameloggedIn = userNameloggedIn+' '+captailizedName
    Amount = request['Amount']
    effectiveDate = request['effectiveDate']
    coverageType =  request['coverageType']
    billFreq =  request['billFreq']
    coverageId = request['coverageId']

    # If necessary, replace us-west-2 with the AWS Region you're using for Amazon SES.
    my_session = boto3.session.Session()
    my_region = my_session.region_name
    AWS_REGION = "us-east-1"
    CHARSET = "UTF-8"
    client = boto3.client('ses', region_name=my_region)
    if APP_NAME == 'OnlinePayment':
        # The subject line for the email.
        SUBJECT = "OnlinePayment Success Payment"

        # The email body for recipients with non-HTML email clients.
        BODY_TEXT = ("Congratulations "+userNameloggedIn+"Your Payment against "+coverageId+ " is completed successfully")

        # The HTML body of the email.
        BODY_HTML = """
                                         <html><body> 
                            <table width=\"100%\" bgcolor=\"#ffffff\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" id=\"backgroundTable\" st-sortable=\"header\"> 
                            <tbody><tr><td> 
                            <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\" class=\"devicewidth\"> 
                            <tbody><tr><td width=\"100%\"> 
                            <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\" class=\"devicewidth\"> 
                            <tbody><tr><td style=\"background-color:#e2e2e2;height:150px;\"> 
                            <table width=\"600\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"devicewidth\"> 
                            <tbody><tr><td width=\"600\"> <div class=\"imgpop\"> 
                            <h1 class=\"headerwidth\" style=\"font-family: Tahoma,Arial,sans-serif;font-size:21px;line-height:27px;color:#333333;font-weight:400;text-align:center;margin:0 auto;\"> 
                            Congratulations {userNameloggedIn}.<br> Your premium payment has successfully been processed, and will appear on your statement as FMG*INS PMT.</h1> 
                            </div> </td> </tr>  </tbody>  </table> </td> </tr> </tbody> </table> </td> </tr> </tbody> </table> </td> </tr> </tbody> </table>                          
                            
                             <table width=\"100%\" bgcolor=\"#ffffff\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" id=\"backgroundTable\" st-sortable=\"2columns\"> 
                            <tbody><tr><td> 
                            <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\" class=\"devicewidth\"> 
                            <tbody><tr><td width=\"100%\"> 
                            <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\" class=\"devicewidth\"> 
                            <tbody><tr><td style=\"background-color:#e2e2e2;height:150px;\"> 
                            <table width=\"600\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"devicewidth\"> 
                            <tbody><tr><td width=\"100%\" height=\"20\"></td> </tr><tr> <td> 
                             <table width=\"500\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"devicewidth\"> 
                            <tbody><tr><td> 
                            <table width=\"450\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"devicewidthinner\" style=\"width:100%;border:2px solid #c2c2c2;border-radius:5px;-moz-border-radius:5px;-webkit-border-radius:5px;border-collapse:separate;\"> 
                            <tbody> <tr> <td width=\"100%\" height=\"20\"></td></tr> <tr> 
                            <td style=\"font-family: Tahoma, Arial, sans-serif;font-size: 18px;color: #333333;font-weight: 600;line-height: 18px;padding-left:35px;text-align:left;\">Your Plan Details</td> 
                            </tr><tr><td width=\"100%\" height=\"20\"></td> </tr> <tr>
                            <td style=\"font-family: Helvetica, arial, sans-serif; font-size: 14px; line-height:24px; color: #666666;padding-left:20px;\"> 
                            <table width=\"450\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"devicewidthinner\" style=\"font-family:Tahoma, Arial,sans-serif;font-size:14px;line-height:24px;color:#333333;margin:0;\"> 
                            <tbody><tr> 
                             <td align=\"left\" style=\"padding:5px;\"><strong>Name:&nbsp;</strong>{userNameloggedIn}</td> 
                            </tr><tr><td align=\"left\" style=\"padding:5px;\"><strong>Coverage ID:&nbsp;</strong>{CoverageID}</td> 
                            </tr>  <tr> <td align=\"left\" style=\"padding:5px;\"><strong>Payment Amount:&nbsp;</strong>${Amount}</td> 
                            </tr> <tr><td align=\"left\" style=\"padding:5px;\"><strong>Effective Date:&nbsp;</strong>{EffectiveDate}</td> 
                            </tr>
							</tbody></table></td></tr><tr><td width=\"100%\" height=\"20\"></td></tr></tbody></table></td> </tr> </tbody> </table> <br><br><br></td> </tr> </tbody> </table> </td> </tr> </tbody> </table> 
                           
                             <table width="100%" bgcolor="#ffffff" cellpadding="0" cellspacing="0" border="0" id="backgroundTable"> 
                            <tbody><tr><td>
                            <table width="650" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth"> 
                            <tbody><tr><td width="100%"> 
                            <table width="650" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth"> 
                            <tbody><tr><td> 
                            <table width="650" align="center" border="0" cellpadding="0" cellspacing="0" class="devicewidth"> 
                            <tbody><tr><td width="100%" height="20"></td> </tr><tr><td> 
                            <table width="600" align="center" border="0" cellpadding="0" cellspacing="0" class="devicewidth"> 
                             <tr><td width="100%" height="20"></td></tr>
							<tr><td style="font-family:Tahoma, Arial,sans-serif; font-size:14px; line-height:20px;color: #333333;text-align:left;"> <strong>The terms of your payment authorization are as follows. Please save this authorization for your records.</strong></td></tr>
							<tr><td width="100%" height="20"></td></tr>
							<tr><td style="font-family:Tahoma, Arial,sans-serif; font-size:14px; line-height:20px;color:#333333;text-align:left;">
                            I authorize the Plan Administrator and it's service provider to charge the credit card<br>
                            indicated in this web form for the noted amount on today's date. This payment is for my
                            <br>{BillFrequency} {CoverageType} insurance premium in the amount of ${Amount}. I may cancel my
                            authorization at any time by contacting the Plan Administrator by calling 1-800-252-2148 or
                            <br> writing P.O. Box 40706, Nashville, TN 37204-0706. My payment Authorization will remain<br>
                            in effect until the Plan Administrator has received and has had reasonable time to act on my<br>
                            request to cancel. I certify that I am an authorized user of this credit card and that I will not<br>
                            dispute the payment with my credit card company, so long as the transaction corresponds<br>
                            to the terms indicated in this web form.
                            <br><br>
                            We continually strive to make your experience with us better. We value your opinion and<br>
                            want to hear from you. Please take a moment to complete a short online survey at:<br>
                            <a target="_blank" href="https://www.research.net/r/webpayacctchng">https://www.research.net/r/webpayacctchng</a> and let us know how we are doing.<br><br>
                            Coverage ID: {CoverageID}
                            <br><br>Sincerely,<br><br>Franklin Madison Group, LLC<br>Plan Administrator</td></tr> <tr> <td width="100%" height="20"></td></tr></tbody></table></td></tr> </tbody></table></td></tr><tr><td width=\"100%\" height=\"10\"></td>
                            </tr></tbody></table></td> </tr> </tbody></table></td></tr></tbody></table>
                           </body></html>
                """
        BODY_HTML = BODY_HTML.format(userNameloggedIn = userNameloggedIn,CoverageID = coverageId,Amount = Amount,EffectiveDate = effectiveDate,BillFrequency = billFreq,CoverageType =coverageType)
    else:
        logger.info("Application is not onlinepayment")
    # Try to send the email.
    try:
        # Provide the contents of the email.
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    RECIPIENT,
                ],
            },
            Message={
                'Body': {
                    'Html': {
                        'Charset': CHARSET,
                        'Data': BODY_HTML,
                    },
                    'Text': {
                        'Charset': CHARSET,
                        'Data': BODY_TEXT,
                    },
                },
                'Subject': {
                    'Charset': CHARSET,
                    'Data': SUBJECT,
                },
            },
            Source=SENDER,
            SourceArn=parameter.get_parameter(parameter_store, 'source_arn'),
        )
    # Display an error if something goes wrong.
    except ClientError as e:
        error_message = {"EmailNotify": {
            "OnlinePayment": "Error in sending mail on success payment for user " + str(RECIPIENT)}}
        error_msgs = json.dumps(error_message)
        logger.error(error_msgs)
        error_msg = e.response['Error']['Message']
        error_response = '{"StatusCode":"500","StatusMessage":"' + error_msg + '"}'
        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": '*', "Access-Control-Allow-Origin": '*'},
            "body": str(error_response)
        }
        return response
    else:
        logger.info("Email sent! Message ID:"),
        response_body = {'StatusMessage': 'Email sent successfully', 'StatusCode': '000'}
        response = {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Headers": '*', "Access-Control-Allow-Origin": '*'},
            "body": str(response_body)
        }
        return response
