from __future__ import print_function
import json
import boto3
import logging
import datetime
import gzip
import urllib
import re
import os
import traceback
#from StringIO import StringIO
#from exceptions import *

logger = logging.getLogger()
logger.setLevel(logging.INFO)


## global functionality
sqs_client = boto3.client('sqs')
s3_client = boto3.client('s3')

def s3AccessLogsGlacierTransition(lines):
    try:
        for line in lines:
            regex = '(?:"([^"]+)")|(?:\[([^\]]+)\])|([^ ]+)'
            data = re.compile(regex).findall(line)
            
            jsondata={}
            jsondata['operation'] = data[6][0] or data[6][1] or data[6][2]
            if(jsondata['operation'] == 'S3.TRANSITION.OBJECT'):
                jsondata['bucketowner'] = data[0][0] or data[0][1] or data[0][2]
                jsondata['bucket'] = data[1][0] or data[1][1] or data[1][2]
                
                logger.info(jsondata)
                
                response = sqs_client.send_message(
                    QueueUrl='https://sqs.us-east-1.amazonaws.com/116762271881/s3_archive_event_dev	',
                    MessageBody=str(jsondata))            
                
    except Exception as e:
        logger.info(e)
        

def handler(event, context):
    ### getting the bucket information and object key information from the event
    s3Bucket = event['Records'][0]['s3']['bucket']['name']
    s3ObjectKey = event['Records'][0]['s3']['object']['key']

    response = s3_client.get_object(Bucket=s3Bucket, Key=s3ObjectKey)
    body = response['Body'].read()
    lines = body.splitlines()
    s3AccessLogsGlacierTransition(lines)