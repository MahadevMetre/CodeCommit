import subprocess
import json
import logging
from datetime import datetime
import sys

stage_name = sys.argv[1]
aws_profile_name = sys.argv[2]
cloudfront_id = sys.argv[3]
lambda_iam_role = 'maintenancegw-lambda-role-'+stage_name
apigw_name = 'maintenancegw-'+stage_name
profile_setting = 'AWS_PROFILE='+aws_profile_name+'&&'


def log_errors(error_statement):
    curr_date = datetime.today().strftime('%Y-%m-%d')
    file_name = 'logs/maintenancegw_logs'+curr_date+'.log'
    logging.basicConfig(filename=file_name,level=logging.ERROR)
    logging.error(error_statement)

def code_deploy():
    try:
        serverless_execution_cmd = ['set', profile_setting, 'serverless', 'deploy', '--stage', stage_name]
        serverless_execution_process = subprocess.Popen(serverless_execution_cmd, stderr=subprocess.PIPE,stdout=subprocess.PIPE, shell=True)
        serverless_execution_output = serverless_execution_process.communicate()[0]
        success_string = 'Stack update finished'
        if success_string in str(serverless_execution_output):
            print(serverless_execution_output)
            print('Successfully deployed code')
            account_details()
        else:
            log_errors(serverless_execution_output)
            error = 'Error in deploying code. Check log files for more details'
            raise Exception(error)
    except Exception as ex:
        print(str(ex))

def account_details():
    try:
        account_details_command = ['set',profile_setting,'aws','sts','get-caller-identity']
        account_details_process = subprocess.Popen(account_details_command,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        account_details_error = account_details_process.stderr.readlines()
        account_details_output = account_details_process.communicate()[0]
        if account_details_error != []:
            log_errors(account_details_error)
            error = 'Error in getting account details for the further process.Check log file for more details.'
            raise  Exception(error)
        else:
            account_details_json = json.loads(account_details_output)
            account_number = account_details_json['Account']
            print ('Successfully retrieved the account number')
            oai_search(account_number)
    except Exception as ex:
        print (str(ex))

def oai_search(account_number):
    try:
            get_distribution_cmd = ['set', profile_setting, 'aws', 'cloudfront', 'get-distribution-config', '--id',
                                    cloudfront_id]
            get_distribution_process = subprocess.Popen(get_distribution_cmd, stderr=subprocess.PIPE,
                                                        stdout=subprocess.PIPE, shell=True)
            get_distribution_output = get_distribution_process.communicate()[0]
            if get_distribution_output == []:
                log_errors(get_distribution_output)
                error = 'Error in getting distribution config of Onlinepayment cloudfront. Check log files for more details.'
                raise Exception(error)
            else:
                get_distribution_json = json.loads(get_distribution_output)
                Items = get_distribution_json['DistributionConfig']['Origins']['Items']
                for items in  Items:
                    access_identity = items['S3OriginConfig']['OriginAccessIdentity']
                    if access_identity != "":
                        success = True
                        oai_list = access_identity.split('/')
                        OAI = oai_list[2]
                        print('OAI is ' + OAI)
                        break
                    else :
                        print ("Trying to get OAI of the cloudfront")

                if success == True:
                    print('Successfully searched OAI')
                    api_id_search(OAI, account_number)
                else:
                    log_errors(get_distribution_output)
                    error = 'error in getting OAI for the cloudfront. Check log file for more details'
                    raise Exception(error)

    except Exception as ex:
            print(str(ex))

def api_id_search(OAI,account_number):
    try:
        api_id_search_cmd = ['set',profile_setting,'aws','apigateway','get-rest-apis','--region','us-east-1']
        api_id_search_process = subprocess.Popen(api_id_search_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        api_id_search_error = api_id_search_process.stderr.readlines()
        api_id_search_output = api_id_search_process.communicate()[0]
        if api_id_search_error != []:
            log_errors(api_id_search_error)
            error = 'error in getting api id of maintenance gw application. Check log file for more details'
            raise Exception(error)
        else:
            api_id_search_json = json.loads(api_id_search_output)
            api_id_list = api_id_search_json['items']
            for api in api_id_list:
                if str(api['name']) == apigw_name:
                    error = False
                    api_id  = api['id']
                    break
                else:
                    print ("Trying to get the api id of maintenance gw application")
            if error == False:
                print('Successfully searched the maintenance gw application api id')
                throttle_rate_edition(OAI,api_id,account_number)
            else:
                log_errors(api_id_search_error)
                error = 'error in getting api id of maintenance gw application. Check log file for more details'
                raise Exception(error)
    except Exception as ex:
        print (str(ex))

def throttle_rate_edition(OAI,api_id,account_number):
    try:
        patch_operation = 'op=replace,path=/*/*/throttling/rateLimit,value=100'
        throttle_rate_edition_cmd = ['set',profile_setting, 'aws', 'apigateway', 'update-stage', '--rest-api-id',api_id, '--stage-name', stage_name, '--patch-operations', patch_operation, '--region','us-east-1']
        throttle_rate_edition_process = subprocess.Popen(throttle_rate_edition_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        throttle_rate_edition_error = throttle_rate_edition_process.stderr.readlines()
        throttle_rate_edition_output = throttle_rate_edition_process.communicate()[0]
        if throttle_rate_edition_error != []:
            log_errors(throttle_rate_edition_error)
            error = 'Error in editing throttle rate limit of the maitenance gw api. Check log file for more details'
            raise Exception(error)
        else:
            print (throttle_rate_edition_output)
            print('Successfully edited throttle rate limit of maintenance gw application api')
            burst_limit_edition(OAI,api_id,account_number)
    except Exception as ex:
        print (str(ex))

def burst_limit_edition(OAI,api_id,account_number):
    try:
        patch_operation = 'op=replace,path=/*/*/throttling/burstLimit,value=100'
        burst_limit_edition_cmd= ['set',profile_setting, 'aws', 'apigateway', 'update-stage', '--rest-api-id',api_id, '--stage-name', stage_name, '--patch-operations', patch_operation, '--region','us-east-1']
        burst_limit_edition_process = subprocess.Popen(burst_limit_edition_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        burst_limit_edition_error = burst_limit_edition_process.stderr.readlines()
        burst_limit_edition_output = burst_limit_edition_process.communicate()[0]
        if burst_limit_edition_error != []:
            log_errors(burst_limit_edition_error)
            error = 'Error in editing burst limit of the maitenance gw api. Check log file for more details'
            raise Exception(error)
        else:
            print (burst_limit_edition_output)
            print('Successfully edited burst limit of maintenance gw application api')
            log_group_creation(OAI,api_id,account_number)
    except Exception as ex:
        print (str(ex))

def log_group_creation(OAI,api_id,account_number):
    try:
        log_group_name = '/aws/apigw-accesslogs-maintenancegw-'+stage_name
        log_group_creation_cmd = ['set',profile_setting, 'aws', 'logs', 'create-log-group', '--log-group-name',log_group_name, '--region', 'us-east-1']
        log_group_creation_process = subprocess.Popen(log_group_creation_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        log_group_creation_error = log_group_creation_process.stderr.readlines()
        log_group_creation_output = log_group_creation_process.communicate()[0]
        if log_group_creation_error != []:
            log_errors(log_group_creation_error)
            error = 'Error in creating log group for maitenance gw api. Check log file for more details'
            raise Exception(error)
        else:
            print (log_group_creation_output)
            print('Successfully created log group for maintenance gw application api')
            api_access_logs(OAI,api_id,log_group_name,account_number)
    except Exception as ex:
        print (str(ex))


def api_access_logs(OAI,api_id,log_group_name,account_number):
    try:
        log_group_arn = 'arn:aws:logs:us-east-1:'+account_number+':log-group:'+ log_group_name
        patch_operation = 'op="replace",path=/accessLogSettings/destinationArn,value="'+log_group_arn+'"'
        api_access_logs_cmd= ['set',profile_setting, 'aws', 'apigateway', 'update-stage', '--rest-api-id',api_id, '--stage-name', stage_name, '--patch-operations', patch_operation, '--region','us-east-1']
        api_access_logs_process = subprocess.Popen(api_access_logs_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        api_access_logs_error = api_access_logs_process.stderr.readlines()
        api_access_logs_output = api_access_logs_process.communicate()[0]
        if api_access_logs_error != []:
            log_errors(api_access_logs_error)
            error = 'Error in enabling access logs to maitenance gw api. Check log file for more details'
            raise Exception(error)
        else:
            print (api_access_logs_output)
            print('Successfully enabled access logs to maintenance gw application api')
            api_log_context(OAI,api_id,account_number)
    except Exception as ex:
        print (str(ex))

def api_log_context(OAI,api_id,account_number):
    try:
        json_format = "\'{\"requestId\":\"$context.requestId\", \"ip\": \"$context.identity.sourceIp\", \"caller\":\"$context.identity.caller\", \"user\":\"$context.identity.user\",\"requestTime\":\"$context.requestTime\", \"httpMethod\":\"$context.httpMethod\",\"resourcePath\":\"$context.resourcePath\", \"status\":\"$context.status\",\"protocol\":\"$context.protocol\", \"responseLength\":\"$context.responseLength\"}\'"
        patch_operation = 'op=add,path=/accessLogSettings/format,value='+json_format
        api_log_context_cmd= ['set',profile_setting, 'aws', 'apigateway', 'update-stage', '--rest-api-id',api_id, '--stage-name', stage_name, '--patch-operations', patch_operation, '--region','us-east-1']
        api_log_context_process= subprocess.Popen(api_log_context_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        api_log_context_error = api_log_context_process.stderr.readlines()
        api_log_context_output = api_log_context_process.communicate()[0]
        if api_log_context_error != []:
            log_errors(api_log_context_error)
            error = 'Error in adding log context to maitenance gw api. Check log file for more details'
            raise Exception(error)
        else:
            print (api_log_context_output)
            print('Successfully added log context to maintenance gw application api')
            api_deployment(OAI,api_id,account_number)
    except Exception as ex:
        print(str(ex))


def api_deployment(OAI,api_id,account_number):
    try:
        api_deployment_cmd = ['set',profile_setting,'aws','apigateway','create-deployment','--rest-api-id',api_id,'--stage-name',stage_name,'--description','API to maitnenance gw application','--region','us-east-1']
        api_deployment_process = subprocess.Popen(api_deployment_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        api_deployment_error = api_deployment_process.stderr.readlines()
        api_deployment_output = api_deployment_process.communicate()[0]
        if api_deployment_error != []:
            log_errors(api_deployment_error)
            error = 'Error in deploying maintenance gw api. Check log files for more details.'
            raise  Exception(error)
        else:
            print(api_deployment_output)
            print('Succesfully deployed private API')
            create_bucket(OAI,api_id,account_number)
    except Exception as ex:
        print (str(ex))

def create_bucket(OAI,api_id,account_number):
    try:
        s3_bucket_name = 'onlinepayment-dustypage-'+stage_name
        create_bucket_cmd = ['set',profile_setting, 'aws', 's3api', 'create-bucket','--bucket',s3_bucket_name]
        create_bucket_process = subprocess.Popen(create_bucket_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        create_bucket_error = create_bucket_process.stderr.readlines()
        create_bucket_output = create_bucket_process.communicate()[0]
        if create_bucket_error != []:
            log_errors(create_bucket_error)
            error = 'Error in creating bucket for onlinepayment error page hosting. Check log files for more details.'
            raise  Exception(error)
        else:
            print(create_bucket_output)
            print('Successfully created bucket for onlinepayment dusty page hosting')
            put_bucket_policy(OAI,api_id,s3_bucket_name,account_number)
    except Exception as ex:
        print (str(ex))

def put_bucket_policy(OAI,api_id,s3_bucket_name,account_number):
    try:
        policy_json ='{"Version": "2008-10-17","Id": "PolicyForCloudFrontPrivateContent","Statement": [{"Sid": "DenyUnEncryptedConnection","Effect": "Deny","Principal": "*","Action": "*","Resource": ["arn:aws:s3:::'+s3_bucket_name+'","arn:aws:s3:::'+s3_bucket_name+'/*"],"Condition": {"Bool": {"aws:SecureTransport": "false"}}},{"Sid": "DenyPublicReadACL","Effect": "Deny","Principal": {"AWS": "*"},"Action": ["s3:PutObject","s3:PutObjectAcl"],"Resource": "arn:aws:s3:::'+s3_bucket_name+'/*","Condition": {"StringEquals": {"s3:x-amz-acl": ["public-read","public-read-write","authenticated-read"]}}},{"Sid": "DenyPublicReadGrant","Effect": "Deny","Principal": {"AWS": "*"},"Action": ["s3:PutObject","s3:PutObjectAcl"],"Resource": "arn:aws:s3:::'+s3_bucket_name+'/*","Condition": {"StringLike": {"s3:x-amz-grant-read": ["*http://acs.amazonaws.com/groups/global/AllUsers*","*http://acs.amazonaws.com/groups/global/AuthenticatedUsers*"]}}},{"Sid": "DenyPublicListACL","Effect": "Deny","Principal": {"AWS": "*"},"Action": "s3:PutBucketAcl","Resource": "arn:aws:s3:::'+s3_bucket_name+'","Condition": {"StringEquals": {"s3:x-amz-acl": ["public-read","public-read-write","authenticated-read"]}}},{"Sid": "DenyPublicListGrant","Effect": "Deny","Principal": {"AWS": "*"},"Action": "s3:PutBucketAcl","Resource": "arn:aws:s3:::'+s3_bucket_name+'","Condition": {"StringLike": {"s3:x-amz-grant-read": ["*http://acs.amazonaws.com/groups/global/AllUsers*","*http://acs.amazonaws.com/groups/global/AuthenticatedUsers*"]}}},{"Sid": "1","Effect": "Allow","Principal": {"AWS": "arn:aws:iam::cloudfront:user/CloudFront Origin Access Identity '+OAI+'"},"Action": "s3:GetObject","Resource": "arn:aws:s3:::'+s3_bucket_name+'/*"}]}'
        put_bucket_policy_cmd = ['set',profile_setting, 'aws', 's3api', 'put-bucket-policy', '--bucket',s3_bucket_name, '--policy', policy_json, '--region', 'us-east-1']
        put_bucket_policy_process = subprocess.Popen(put_bucket_policy_cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,shell=True)
        put_bucket_policy_error = put_bucket_policy_process.stderr.readlines()
        put_bucket_policy_output = put_bucket_policy_process.communicate()[0]
        if put_bucket_policy_error != []:
            log_errors(put_bucket_policy_error)
            error = 'Error in adding bucket policy to dusty page bucket. Check log files for more details.'
            raise Exception(error)
        else:
            print(put_bucket_policy_output)
            print('Successfully added bucket policy to dusty page bucket')
            put_bucket_encryption(api_id,s3_bucket_name,account_number)
    except Exception as ex:
        print(str(ex))

def put_bucket_encryption(api_id,s3_bucket_name,account_number):
    try:
        encryption_json = '{"Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]}'
        put_bucket_encryption_cmd = ['set',profile_setting, 'aws', 's3api', 'put-bucket-encryption','--bucket',s3_bucket_name,'--server-side-encryption-configuration',encryption_json,'--region', 'us-east-1']
        put_bucket_encryption_process = subprocess.Popen(put_bucket_encryption_cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,shell=True)
        put_bucket_encryption_error = put_bucket_encryption_process.stderr.readlines()
        put_bucket_encryption_output = put_bucket_encryption_process.communicate()[0]
        if put_bucket_encryption_error != []:
            log_errors(put_bucket_encryption_process)
            error = 'Error in adding bucket encryption to dusty page bucket. Check log files for more details.'
            raise Exception(error)
        else:
            print(put_bucket_encryption_output)
            print('Successfully added bucket encryption to dusty page bucket')
            bucket_access_policy(api_id,s3_bucket_name,account_number)
    except Exception as ex:
        print(str(ex))

def bucket_access_policy(api_id,s3_bucket_name,account_number):
    try:
        access_configuration = 'BlockPublicAcls=True,IgnorePublicAcls=True,BlockPublicPolicy=True,RestrictPublicBuckets=True'
        bucket_access_policy_cmd = ['set',profile_setting, 'aws', 's3api', 'put-public-access-block','--bucket',s3_bucket_name,'--public-access-block-configuration',access_configuration]
        bucket_access_policy_process = subprocess.Popen(bucket_access_policy_cmd, stderr=subprocess.PIPE,stdout=subprocess.PIPE, shell=True)
        bucket_access_policy_error = bucket_access_policy_process.stderr.readlines()
        bucket_access_policy_output = bucket_access_policy_process.communicate()[0]
        if bucket_access_policy_error != []:
            log_errors(bucket_access_policy_error)
            error = 'Error in adding bucket access policy to dusty page bucket. Check log files for more details.'
            raise Exception(error)
        else:
            print(bucket_access_policy_output)
            print('Successfully added bucket access policy to dusty page bucket')
            get_distribution(api_id,s3_bucket_name,account_number)

    except Exception as ex:
        print(str(ex))

def get_distribution(api_id,s3_bucket_name,account_number):
    try:
        get_distribution_cmd = ['set',profile_setting,'aws','cloudfront','get-distribution-config','--id',cloudfront_id]
        get_distribution_process = subprocess.Popen(get_distribution_cmd, stderr=subprocess.PIPE,stdout=subprocess.PIPE, shell=True)
        get_distribution_output = get_distribution_process.communicate()[0]
        if get_distribution_output == []:
            log_errors(get_distribution_output)
            error = 'Error in getting distribution config of Onlinepayment cloudfront. Check log files for more details.'
            raise Exception(error)
        else:
            get_distribution_json = json.loads(get_distribution_output)
            get_distribution_json_new = json.loads(get_distribution_output)
            print(type(get_distribution_json))
            get_distribution_json['DistributionConfig']['Origins']['Quantity'] = 2
            get_distribution_json_new['DistributionConfig']['Origins']['Items'][0]['Id'] = s3_bucket_name+'-origin'
            get_distribution_json['DistributionConfig']['Origins']['Items'].append(get_distribution_json_new['DistributionConfig']['Origins']['Items'][0])
            print(get_distribution_json['DistributionConfig']['Origins']['Items'])
            ETag = get_distribution_json['ETag']
            get_distribution_json['DistributionConfig']['Origins']['Items'][1]['DomainName'] = s3_bucket_name+'.s3.amazonaws.com'
            update_distribution(api_id,get_distribution_json['DistributionConfig'], ETag,account_number)

    except Exception as ex:
        print(str(ex))

def update_distribution(api_id,distribution_config,ETag,account_number):
    try:
        update_distribution = json.dumps(distribution_config)
        app_distribution_name = distribution_config['Origins']['Items'][0]['Id']
        dustypage_distribution_name = distribution_config['Origins']['Items'][1]['Id']
        update_distribution_cmd = ['set',profile_setting, 'aws', 'cloudfront', 'update-distribution','--distribution-config',update_distribution,'--id',cloudfront_id,'--if-match',ETag]
        update_distribution_process = subprocess.Popen(update_distribution_cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,shell=True)
        update_distribution_output = update_distribution_process.stdout.readlines()
        if 'error' in str(update_distribution_output):
            log_errors(update_distribution_output)
            error = 'Error in updating cloudfront distribution with dusty page'
            raise Exception(error)
        else:
            print(update_distribution_output)
            print('Successfully updated cloud front distribution with dusty page')
            kms_creation(api_id,account_number,app_distribution_name,dustypage_distribution_name)
    except Exception as ex:
        print(str(ex))

def kms_creation(api_id,account_number,app_distribution_name,dustypage_distribution_name,):
    try:
        policy_stmt = '{"Id": "kms-policy","Version": "2012-10-17","Statement": [{"Sid": "Enable IAM User Permissions","Effect": "Allow","Principal": {"AWS": "arn:aws:iam::' + account_number + ':root"},"Action": "kms:*","Resource": "*"},{"Sid": "Allow access for Key Administrators","Effect": "Allow","Principal": {"AWS": "arn:aws:iam::' + account_number + ':role/Franklin-Admin-NonProd"},"Action": ["kms:Create*","kms:Describe*","kms:Enable*","kms:List*","kms:Put*","kms:Update*","kms:Revoke*","kms:Disable*","kms:Get*","kms:Delete*","kms:TagResource","kms:UntagResource"],"Resource": "*"},{"Sid": "Allow use of the key","Effect": "Allow","Principal": {"AWS": "arn:aws:iam::' + account_number + ':role/' + lambda_iam_role + '"},"Action": ["kms:Encrypt","kms:Decrypt","kms:ReEncrypt*","kms:GenerateDataKey*","kms:DescribeKey"],"Resource": "*"},{"Sid": "Allow attachment of persistent resources","Effect": "Allow","Principal": {"AWS": "arn:aws:iam::' + account_number + ':role/' + lambda_iam_role + '"},"Action": ["kms:CreateGrant","kms:ListGrants","kms:RevokeGrant"],"Resource": "*","Condition": {"Bool": {"kms:GrantIsForAWSResource": "true"}}}]}'
        kms_creation_cmd = ['set',profile_setting, 'aws', 'kms', 'create-key', '--policy',policy_stmt, '--description', 'key_to_encrypt_decrypt_parameters','--key-usage', 'ENCRYPT_DECRYPT', '--origin', 'AWS_KMS','--bypass-policy-lockout-safety-check', '--region', 'us-east-1']
        kms_creation_process = subprocess.Popen(kms_creation_cmd, stderr=subprocess.PIPE,stdout=subprocess.PIPE, shell=True)
        kms_creation_error = kms_creation_process.stderr.readlines()
        kms_creation_output = kms_creation_process.communicate()[0]
        if kms_creation_error != []:
            log_errors(kms_creation_error)
            error = 'Error in creating customer managed key (kms).Check log file for more details.'
            raise  Exception(error)
        else:
            print (kms_creation_output)
            kms_creation_json = json.loads(kms_creation_output)
            key_id = kms_creation_json['KeyMetadata']['KeyId']
            print (key_id)
            alias_creation(api_id,key_id,app_distribution_name,dustypage_distribution_name)
    except Exception as ex:
        print(str(ex))

def alias_creation(api_id,key_id,app_distribution_name,dustypage_distribution_name):
    try:
        alias_name = 'alias/maintenancegw2-kms'+stage_name
        alias_creation_cmd = ['set',profile_setting, 'aws', 'kms', 'create-alias', '--alias-name',alias_name, '--target-key-id', key_id, '--region', 'us-east-1']
        alias_creation_process = subprocess.Popen(alias_creation_cmd, stderr=subprocess.PIPE,stdout=subprocess.PIPE, shell=True)
        alias_creation_error = alias_creation_process.stderr.readlines()
        alias_creation_output = alias_creation_process.communicate()[0]
        if alias_creation_error != []:
            log_errors(alias_creation_error)
            error = 'Error in creating alias for customer managed key (kms).Check log file for more details.'
            raise  Exception(error)
        else:
            print (alias_creation_output)
            print ("Successfully created alias for customer managaed key (kms)")
            parameter_store_creation(api_id,key_id,app_distribution_name,dustypage_distribution_name)
    except Exception as ex:
        print(str(ex))

def parameter_store_creation(api_id,key_id,app_distribution_name,dustypage_distribution_name):
    try:
        param_name = 'maintenancegw-parameters-'+stage_name
        param_value = '{"Access-Control-Allow-Origin":"*","onlinePayment_distributionId":"'+cloudfront_id+'","onlinePayment_originId":"'+app_distribution_name+'","onlinePayment_dustyPage_originId":"'+dustypage_distribution_name+'"}'
        key_id = key_id
        parameter_store_cmd = ['set',profile_setting, 'aws', 'ssm', 'put-parameter','--name',param_name,'--value',param_value,'--type','SecureString','--key-id',key_id,'--region','us-east-1']
        parameter_store_process = subprocess.Popen(parameter_store_cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,shell=True)
        parameter_store_error = parameter_store_process.stderr.readlines()
        parameter_store_output = parameter_store_process.communicate()[0]
        if parameter_store_error != []:
            log_errors(parameter_store_error)
            error = 'Error in creating parameter store.Check log file for more details.'
            raise Exception(error)
        else:
            print(parameter_store_output)
            print("Successfully created parameter store for maintenance gw application")
            waf_cloudfront(api_id)

    except Exception as ex:
        print(str(ex))

def waf_cloudfront(api_id):
    try:
        waf_cloudfront_cmd = ['set', profile_setting, 'aws', 'waf', 'list-web-acls']
        waf_cloudfront_process = subprocess.Popen(waf_cloudfront_cmd, stderr=subprocess.PIPE,stdout=subprocess.PIPE, shell=True)
        waf_cloudfront_error = waf_cloudfront_process.stderr.readlines()
        waf_cloudfront_output = waf_cloudfront_process.communicate()[0]
        search_string = 'onlinepayment'
        if waf_cloudfront_error != []:
            log_errors(waf_cloudfront_error)
            error = 'error in getting web acls. Check log file for more details'
            raise Exception(error)
        else:
            waf_cloudfront_json = json.loads(waf_cloudfront_output)
            web_acl_list = waf_cloudfront_json['WebACLs']
            for web_acl in web_acl_list:
                if search_string in web_acl['Name']:
                    error = False
                else:
                    print ("Trying to get web acl id")
            if error == False:
                print('Successfully searched web acl id')
                print(web_acl['WebACLId'])
                web_acl_id = str(web_acl['WebACLId'])
                resource_creation(api_id,web_acl_id)
            else:
                log_errors(waf_cloudfront_output)
                error = 'error in getting web acl id. Check log files for more details'
                raise Exception(error)
    except Exception as ex:
        print(str(ex))

def resource_creation(api_id,web_acl_id):
    try:
        print (api_id)
        print (type(web_acl_id))
        print(lambda_iam_role)
        stack_name  = 'cf-maintenancegw-'+stage_name
        template_location =  'file://maintenancegw_resource_creation.yml'
        parameter1 = 'ParameterKey=DeploymentStage,ParameterValue='+stage_name
        parameter2 = 'ParameterKey=ApiID,ParameterValue='+api_id
        parameter3 = 'ParameterKey=LambdaIAMRole,ParameterValue='+lambda_iam_role
        parameter4 = 'ParameterKey=WebAclId,ParameterValue='+web_acl_id
        resource_creation_cmd = ['set',profile_setting, 'aws', 'cloudformation','create-stack','--stack-name',stack_name,'--template-body', template_location, '--parameters', parameter1,parameter2,parameter3,parameter4,'--capabilities', 'CAPABILITY_NAMED_IAM', '--region', 'us-east-1']
        resource_creation_process = subprocess.Popen(resource_creation_cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        resource_creation_error = resource_creation_process.stderr.readlines()
        resource_creation_output = resource_creation_process.communicate()[0]
        if resource_creation_error != []:
            log_errors(resource_creation_error)
            error = 'Error in creating resources for maintenance gw application. Check log files for more details.'
            raise  Exception(error)
        else:
            print(resource_creation_output)
            print('Successfully created resources required for maintenance gw application')
    except Exception as ex:
        print (str(ex))

code_deploy()