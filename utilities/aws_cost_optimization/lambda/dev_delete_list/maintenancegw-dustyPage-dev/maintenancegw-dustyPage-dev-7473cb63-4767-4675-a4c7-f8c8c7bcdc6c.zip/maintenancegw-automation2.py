import subprocess
import json
import logging
from datetime import datetime
import sys

stage_name = sys.argv[1]
aws_profile_name = sys.argv[2]
user_pool_id = sys.argv[3]
client_id = sys.argv[4]
username = sys.argv[5]
password = sys.argv[6]
lambda_iam_role = 'maintenancegw-lambda-role-'+stage_name
apigw_name = 'maintenancegw-'+stage_name
profile_setting = 'AWS_PROFILE='+aws_profile_name+'&&'


def log_errors(error_statement):
    curr_date = datetime.today().strftime('%Y-%m-%d')
    file_name = 'logs/maintenancegw_logs'+curr_date+'.log'
    logging.basicConfig(filename=file_name,level=logging.ERROR)
    logging.error(error_statement)

def user_creation():
    try:
        user_creation_cmd = ['set', profile_setting, 'aws', 'cognito-idp', 'sign-up','--client-id',client_id,'--username',username,'--password',password,'--region','us-east-1']
        user_creation_process = subprocess.Popen(user_creation_cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,shell=True)
        user_creation_error = user_creation_process.stderr.readlines()
        user_creation_output = user_creation_process.communicate()[0]
        if user_creation_error != []:
            log_errors(user_creation_error)
            error = 'Error in creating user for maintenance gw application in cognito. Check log files for more details.'
            raise Exception(error)
        else:
            print(user_creation_output)
            print('Successfully created user in cognito required for maintenance gw application')
            user_confirmation(username)

    except Exception as ex:
        print(str(ex))

def user_confirmation(username):
    try:
        user_confirmation_cmd = ['set', profile_setting, 'aws', 'cognito-idp', 'admin-confirm-sign-up','--user-pool-id',user_pool_id,'--username',username,'--region','us-east-1']
        user_confirmation_process = subprocess.Popen(user_confirmation_cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,shell=True)
        user_confirmation_error = user_confirmation_process.stderr.readlines()
        user_confirmation_output = user_confirmation_process.communicate()[0]
        if user_confirmation_error != []:
            log_errors(user_confirmation_error)
            error = 'Error in confirming user for maintenance gw application in cognito. Check log files for more details.'
            raise Exception(error)
        else:
            print(user_confirmation_output)
            print('Successfully confirmed user in cognito required for maintenance gw application')
            mail_verification(username)

    except Exception as ex:
        print(str(ex))

def mail_verification(username):
    try:
        user_attributes = 'Name=email_verified,Value=true'
        mail_verification_cmd = ['set', profile_setting, 'aws', 'cognito-idp', 'admin-update-user-attributes','--user-pool-id',user_pool_id,'--username',username,'--user-attributes',user_attributes,'--region','us-east-1']
        mail_verification_process = subprocess.Popen(mail_verification_cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,shell=True)
        mail_verification_error = mail_verification_process.stderr.readlines()
        mail_verification_output = mail_verification_process.communicate()[0]
        if mail_verification_error != []:
            log_errors(mail_verification_error)
            error = 'Error in verifying user mail ID for maintenance gw application in cognito. Check log files for more details.'
            raise Exception(error)
        else:
            print(mail_verification_output)
            print('Successfully verified user mail ID in cognito required for maintenance gw application')

    except Exception as ex:
        print(str(ex))


user_creation()