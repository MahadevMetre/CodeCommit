
const AWS = require('aws-sdk')
let env1 = null;
let env2 = null;


function decryptKMS(key) {
  return new Promise((resolve, reject) => {
    const kms = new AWS.KMS()
    kms.decrypt({ CiphertextBlob: new Buffer(key, 'base64') }, (err, data) => {
      if(err) {
        reject(err)
      }
      else {
        resolve(data.Plaintext.toString('ascii'))
      }
    }) 
  })
}

async function  callDecryptKMS(){
   let key1=null;
   const keys = [process.env.env1, process.env.env2 ];
    await Promise.all(keys.map(decryptKMS))
  .then(([decryptedkey1, decryptedkey2]) => {
    // use decryptedkeyN here 
    env1=decryptedkey1
    env2=decryptedkey2;
    return [decryptedkey1, decryptedkey2];
    
  })
  .catch((e) => console.log('error', e))
}

  
exports.handler =   function (event, context) {
        let a = null;
     a  =  callDecryptKMS();
     a.then((e)=> {
       // 
       console.log('promise completed', env1, env2)
      
    
    const response = {
        statusCode: 200,
        body: JSON.stringify(env1),
    };
    return response;
     });
};



