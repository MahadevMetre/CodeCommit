import boto3
import json
import time
import os
client = boto3.client('textract')

class Claims:
 
 bucket=""
 document=""
 
 def __init__(self):
  print('claims service initiated')
  self.bucket = os.environ.get("bucketName","captiva-files")
  self.document = os.environ.get("documentName","test.png")
  
 def textract(self,event,context):
  try:
   print('claim service textracting')
   #process using S3 object
   response = client.detect_document_text(
    Document={
     'S3Object': {
      'Bucket': self.bucket,
      'Name': self.document
     }
     }
    )
   #Get the text blocks
   blocks=response['Blocks']
   print('pring output')
   print(blocks)
   return {
    'statusCode': 200,
    'body': json.dumps(blocks)
    }  
  except Exception as ex:
   print(repr(ex))
   return repr(ex)
  
 