import json
from services import Claims

def lambda_handler(event, context):
    try:
        print(event)
        claims = Claims()
        #return claims.textract(event,context)
       
        #const taskToken = executionContext.Task.Token;
        #onsole.log('taskToken= ' + taskToken);
        #return "Tasktoken Value : " + taskToken; 
        return "Response from Captiva Claims Lambda"
    except Exception as e:
        print(repr(e))
        return {
            'statusCode':500,
            'body':json.dumps(repr(e))
        }