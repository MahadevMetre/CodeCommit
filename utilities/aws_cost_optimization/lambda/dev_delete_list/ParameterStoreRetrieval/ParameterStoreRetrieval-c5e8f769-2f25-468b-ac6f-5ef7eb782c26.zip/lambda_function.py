import json

import logging
import boto3
from json import loads
import datetime

orderIdGlobal=''
updatedDateTimeGlobal =''
angularStatusCode =''
angularStatusMessage =''
#---------------Main program execution -------------------------------------
def lambda_handler(event, context):
    try:
        logger = logging.getLogger()
        logger.info('test')
        dynamoclient = boto3.client('dynamodb')
        print ("before connection")
        response = dynamoclient.update_item(
            TableName='onlinepayment-transaction-dev',
            Key={
                'BILLING_ID' : {"S":"1"},
                'CREATED_DATE_TIME' : {"S":"1"}
            },
            UpdateExpression="set LITLETXNID = :littleTxnId ,STATUS_CODE = :statusCode , STATUSMESSAGE =:statusMessage , LITLERESPONSECODE = :litleResponseCode ,LITLERESPONSETIME = :litleResponseTime ,LITLEAUTHCODE = :litleAuthCode , UPDATED_DATE_TIME = :updatedDateTime",

            ExpressionAttributeValues={

                ':littleTxnId': {"S": "1"},
                ':statusCode': {"S": "1"},
                ':statusMessage': {"S": "1"},
                ':litleResponseCode': {"S": "1"},
                ':litleResponseTime': {"S": "1"},
                ':litleAuthCode': {"S": "1"},
                ":updatedDateTime": {"S": datetime.datetime.now().isoformat()}
            }
        )
        print ("after connection state")

    except Exception as ex:
        print("Error in  updating transacion to DynamoDB " + str(ex))
        response = '1'
        return response
    print("response from update billing table")
    print(response)

