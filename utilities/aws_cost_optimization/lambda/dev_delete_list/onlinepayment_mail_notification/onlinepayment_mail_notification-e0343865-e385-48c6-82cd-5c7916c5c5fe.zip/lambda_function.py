import smtplib
import os

def send_email(host, port, username, password, subject, body, mail_to, mail_from = None, reply_to = None):
    if mail_from is None: mail_from = username
    if reply_to is None: reply_to = mail_to

    message = """From: %s\nTo: %s\nReply-To: %s\nSubject: %s\n\n%s""" % (mail_from, mail_to, reply_to, subject, body)
    print (message)
    try:
        server = smtplib.SMTP(host, port)
        server.ehlo()
        server.starttls()
        server.login(username, password)
        server.sendmail(mail_from, mail_to, message)
        server.close()
        return True
    except Exception as ex:
        print (ex)
        return False

def lambda_handler(event, context):

    # initialize variables
    username = os.environ['USERNAME']
    password = os.environ['PASSWORD']
    host = os.environ['SMTPHOST']
    port = os.environ['SMTPPORT']
    mail_from = os.environ.get('MAIL_FROM')
    mail_to = os.environ['MAIL_TO']     # separate multiple recipient by comma. eg: "abc@gmail.com, xyz@gmail.com"

    reply_to = None
    subject = 'this is a test mail'
    body = 'this is test mail'
    
    # vaildate cors access
    success = send_email(host, port, username, password, subject, body, mail_to, mail_from, reply_to)

    # prepare response
    response = {
        "isBase64Encoded": False,
        "headers": { "Access-Control-Allow-Origin": '*' }
    }
    if success:
        response["statusCode"] = 200
        response["body"] = '{"status":true}'
    else:
        response["statusCode"] = 400
        response["body"] = '{"status":false}'
    return response