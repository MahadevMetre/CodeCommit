import json
import boto3

def lambda_handler(event, context):
    # TODO implement
  
    my_session = boto3.session.Session()
    my_region = my_session.region_name
    print("Lambda function ARN:", my_region)
    return {
        'statusCode': 200,
        'body': my_region
    }
