const express = require('express');
const log4js = require('log4js');

//Get the custom hostname from bash script
const server_hostname = process.env.CUSTOM_HOSTNAME;

//Rotate log files when logfile size reaches 10MB
log4js.configure({
  appenders: {
    logappender: {
					type: 'file', 
					filename: '/common/logs/uiapps/nemesysnextgen/'+server_hostname+'/NemesysNextGenUI.log', 
					maxLogSize: 10485760, 
					backups: 10, 
					compress: true
				 }
  },
  categories: {
    default: { appenders: [ 'logappender' ], level: 'debug'}
  }
});
const app = express();
app.use(express.json());

 
//READ Request Handlers
app.get('/', (req, res) => {
const logger = log4js.getLogger('logappender');
logger.info('api reached');


	res.send('Welcome to API');
});
 
app.get('/api/nemesysnextgenlogger', (req,res)=> {
 
const logger = log4js.getLogger('logappender');
logger.info(req);

res.send('Welcome to API');
});

 
//CREATE Request Handler
app.post('/api/nemesysnextgenlogger', (req, res)=> {

const logger = log4js.getLogger('logappender');

let date_ob = new Date();

// current date
// adjust 0 before single digit date
let date = ("0" + date_ob.getDate()).slice(-2);

// current month
let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);

// current year
let year = date_ob.getFullYear();

// current hours
let hours = date_ob.getHours();

// current minutes
let minutes = date_ob.getMinutes();

// current seconds
let seconds = date_ob.getSeconds();


if(req.body.level == 5){		
	logger.error('messgae : ' + req.body.message + ' file name : ' + req.body.fileName + ' line number : ' + req.body.lineNumber + ' timestamp : ' + year + '-' + month + '-' + date + ' ' + hours + ':' + minutes + ':' + seconds);
}
else
{
	logger.info('messgae : ' + req.body.message + ' file name : ' + req.body.fileName + ' line number : ' + req.body.lineNumber + ' timestamp : ' + year + '-' + month + '-' + date + ' ' + hours + ':' + minutes + ':' + seconds);
}

res.send('Success');
});
  
//PORT ENVIRONMENT VARIABLE
const port = process.env.PORT || 3006;
app.listen(port, () => console.log('Listening on port ${port}..'));