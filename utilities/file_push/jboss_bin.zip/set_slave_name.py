#!/usr/bin/python3.6
import sys, subprocess, os, errno, random, string
import xml.dom.minidom as md

# Function for creating a random string of length: length
def randomword(length):
   letters = string.ascii_lowercase
   return ''.join(random.choice(letters) for i in range(length))

# This line of code gets the ec2 instance Id and stores it in a string variable, use this for production
res = subprocess.Popen("curl --max-time 12 http://169.254.169.254/latest/meta-data/instance-id", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
res.wait()
if res.returncode == 0:
    instanceId = res.communicate()[0]
    print('EC2 Instance Id: ' + instanceId.decode('utf-8'))
else:
    instanceId = randomword(12)
    print('Faied to retrieve EC2 Instance Id, using a random generated string: ' + instanceId)

# xml file to parse
print('\nCurrent working directory: ' + str(os.getcwd()))
print('Parsing XML file at location: ' + str(sys.argv[1]))
root = md.parse(str(sys.argv[1]))

servers = root.getElementsByTagName("server")
i = 0
for server in servers:
    server.setAttribute("name", instanceId.decode('utf-8') + "-" + str(i))
    print('\nChanging Server Name with Server group: ' + server.getAttribute("group") + ' to ' + server.getAttribute("name"))

    # Create the /common/logs/insuranceapps/serverName directory if it doesn't exists
    directory = "/common/logs/insuranceapps/" + server.getAttribute("name")
    try:
        os.makedirs(directory)
        print('Directory: ' + directory + ' created')
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    i += 1

with open( str(sys.argv[1]), "w" ) as fs:
    fs.write(root.toxml())
    fs.close()
