#!/bin/sh

USERID=`/usr/bin/whoami`

if [ "$USERID" != "jbadmin" ]; then
        echo "Please execute script using with jbadmin user"
        exit 1
fi


USER=admin
PASS=Jb@dm1n@FmG

/opt/web/current/bin/jboss-cli.sh --connect --controller=https-remoting://${HOSTNAME}:9990 --user=${USER} --password=${PASS} /host=insuranceappsm:shutdown
