#!/bin/sh

USERID=`/usr/bin/whoami`

if [ "$USERID" != "jbadmin" ]; then
        echo "Please execute script using with jbadmin user"
        exit 1
fi

JBOSS_BIN="/opt/web/current/bin"
BIND_ADDRESS=$HOSTNAME
MASTER_ADDRESS="uset1apci115.franklinmadisonds.com"
DOMAIN_DIR="/opt/web/projects/insuranceapps"
HOST_CONFIG="host-slave-insuranceapps.xml"
EXT_DIR="/opt/web/etc/insuranceapps:/opt/web/javalib"
LOG_DIR="/common/logs/insuranceapps/slaves"

DATE=`date +%m%d%y%H%M%S`
find ${LOG_DIR} -type f \( -name "*.out" -o -name "*.log" \) -exec mv {} {}_${DATE} \;

/opt/web/bin/set_slave_name.py /opt/web/projects/insuranceapps/configuration/host-slave-insuranceapps.xml

cd ${DOMAIN_DIR}/configuration

${JBOSS_BIN}/domain.sh -Djboss.domain.master.address=${MASTER_ADDRESS} -Djboss.server.name=${BIND_ADDRESS} -Djboss.bind.address=${BIND_ADDRESS} -Djboss.bind.address.management=${BIND_ADDRESS} -Djboss.domain.base.dir=${DOMAIN_DIR} -Djavax.net.ssl.trustStore=/opt/web/certs/trust.jks  -Djavax.net.ssl.trustStoreType=JKS --host-config=${HOST_CONFIG} --cached-dc > ${LOG_DIR}/slave-$HOSTNAME.out 2>1 &

echo "Starting Insurance apps slave $HOSTNAME Check Logs"
echo "tail -f ${LOG_DIR}/slave-$HOSTNAME.out"
