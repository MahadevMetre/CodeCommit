#!/bin/sh

USERID=`/usr/bin/whoami`

if [ "$USERID" != "jbadmin" ]; then
        echo "Please execute script using with jbadmin user"
        exit 1
fi

JBOSS_BIN="/opt/web/current/bin"
BIND_ADDRESS=$HOSTNAME
DOMAIN_DIR="/common/apps/admin"
HOST_CONFIG="host-master.xml"
LOG_DIR=/common/logs/insuranceapps/admin

DATE=`date +%m%d%y%H%M%S`
find ${LOG_DIR} -type f \( -name "*.out" -o -name "*.log" \) -exec mv {} {}_${DATE} \;

cd ${DOMAIN_DIR}/configuration

${JBOSS_BIN}/domain.sh  -Djboss.bind.address=${BIND_ADDRESS} -Djboss.bind.address.management=${BIND_ADDRESS} -Djboss.domain.base.dir=${DOMAIN_DIR} --host-config=${HOST_CONFIG} > ${LOG_DIR}/admin.out 2>1 &

echo "Log location"
echo "tail -f ${LOG_DIR}/admin.out"
