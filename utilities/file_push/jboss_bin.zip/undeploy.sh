#!/bin/sh

APPNAME=$1
CLUSTER=$2

usage()
{
        echo "Usage: ./undeploy.sh <filename> -optional <cluster>"
        exit 1
}

if [ ${#} = 0 ]; then
        usage
fi

if [ -z "$CLUSTER" ]; then
        SGROUP="insuranceappscluster"
        echo "Undeploying from insuranceapps cluster"
else
        SGROUP="batchappscluster"
        echo "Undeploying from batchapps cluster"
fi


USER=admin
PASS=Jb@dm1n@FmG
DCONTROLLER="https-remoting://${HOSTNAME}:9990"
/opt/web/current/bin/jboss-cli.sh --connect --controller=${DCONTROLLER} --user=${USER} --password=${PASS} --commands="undeploy ${APPNAME} --server-groups=${SGROUP}"
