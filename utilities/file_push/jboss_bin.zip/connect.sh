#!/bin/sh

USER=admin
PASS=Jb@dm1n@FmG

DCONTROLLER="https-remoting://${HOSTNAME}:9990"
/opt/web/current/bin/jboss-cli.sh --connect --controller=${DCONTROLLER} --user=${USER} --password=${PASS} $*
