#!/bin/sh

USER=admin
PASS=Jb@dm1n@FmG

DCONTROLLER="https-remoting://$HOSTNAME:9990"
dir=$1

inotifywait -m $dir -e create -e moved_to |
	while read dir action file; do
		echo "The file '$file' appeared in directory '$dir' via '$action'"
		sleep 15m
		/opt/web/current/bin/jboss-cli.sh  --connect --controller=${DCONTROLLER} --user=${USER} --password=${PASS}  --commands="/core-service=management/host-connection=master:prune-expired"
		/opt/web/current/bin/jboss-cli.sh  --connect --controller=${DCONTROLLER} --user=${USER} --password=${PASS}  --commands="/core-service=management/host-connection=master:prune-disconnected"
	done
