# User/Role is added to files located under /common/apps/admin/configuration
# The cp commands then copies it to other locations where configs are placed

RED='\033[0;31m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

/opt/web/current/bin/add-user.sh -dc /common/apps/admin/configuration

printf  "${PURPLE}\n\nChoose the properties files to copy.\n${NC}"
printf  "${GREEN} a) Management User (mgmt-*.properties)\n${NC}"
printf  "${GREEN} b) Application User (application-*.properties)\n${NC}"
printf  "${GREEN} c) Both a & b\n${NC}"
printf  "${RED} d) Do not copy\n${NC}"
printf  "${PURPLE} Enter your choice : ${BLUE}"
read copyvar
if [[ $copyvar == "a" || $copyvar == "c" ]]; then
	cp /common/apps/admin/configuration/mgmt-*.properties /common/apps/batchapps/configuration/
	cp /common/apps/admin/configuration/mgmt-*.properties /opt/web/projects/insuranceapps/configuration/
	printf  "${GREEN} mgmt-*.properties files are copied\n${NC}"
elif [[ $copyvar != "b" ]]; then
	printf  "${RED} mgmt-*.properties files are not copied\n${NC}"
fi
if [[ $copyvar == "b" || $copyvar == "c" ]]; then
	cp /common/apps/admin/configuration/application-*.properties /common/apps/batchapps/configuration/
	cp /common/apps/admin/configuration/application-*.properties /opt/web/projects/insuranceapps/configuration/
	printf  "${GREEN} application-*.properties files are copied\n${NC}"
elif [[ $copyvar != "a" ]]; then
	printf  "${RED} application-*.properties files are not copied\n${NC}"
fi