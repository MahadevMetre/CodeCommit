#!/bin/sh

FILE=$1
CLUSTER=$2

usage()
{
        echo "Usage: ./deploy.sh <filename> -optional <cluster>"
        exit 1
}

if [ ${#} = 0 ]; then
        usage
fi

if [ -z "$CLUSTER" ]; then
        SGROUP="insuranceappscluster"
        echo "Deploying in insuranceapps cluster"
else
        SGROUP="batchappscluster"
        echo "Deploying in batchapps cluster"
fi

DFILE=/opt/web/deployments/insuranceapps/$FILE
USER=admin
PASS=Jb@dm1n@FmG
DCONTROLLER="https-remoting://${HOSTNAME}:9990"
/opt/web/current/bin/jboss-cli.sh --connect --controller=${DCONTROLLER} --user=${USER} --password=${PASS} --commands="deploy ${DFILE} --server-groups=${SGROUP}"
