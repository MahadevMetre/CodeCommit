import json
import os
import datetime
import boto3
import math
from datetime import timedelta, timezone
import dateutil.tz
from boto3.dynamodb.conditions import Key

def lambda_handler(event, context):
    print(event)

    # Batch Modes - FullLoad, S3, Incremental Schedule
    i_inputtype = None
    i_bucketname = None
    i_filename = None
    i_s3filepath = None
    userId = None
    strFileDateTime = None
    strTimeInterval = None
    strCCStartIntervalDateTime = None
    strCCEndIntervalDateTime = None
    target_db = None
    changes_db = None
    db_creds = None

    try:
        # Note: detail-type is present only for s3 and scheduled triggers. Not for FullLoad.
        i_inputtype = event['detail-type']
    except:
        i_inputtype = "FULL"
        strExtractName = "FullLoad"
        userId = "FullLoad"

    print(i_inputtype)

    if (i_inputtype is "FULL"):
        strBatchId = "FULL_" + datetime.datetime.now().strftime("%m%d%y%H%M%S")
        print(strBatchId)
        strCCStartIntervalDateTime = datetime.datetime.now().strftime("%m/%d/%Y %H:%M")
        strCCEndIntervalDateTime = datetime.datetime.now().strftime("%m/%d/%Y %H:%M")

    elif i_inputtype == "Scheduled Event":

        i_scheduleddatetime = event['time']
        print("CC Scheduled Trigger Time " + i_scheduleddatetime)
        dtCurrentDateTime = datetime.datetime.strptime(i_scheduleddatetime, "%Y-%m-%dT%H:%M:%SZ")

        #Check if any current processing records are available
        db_table = boto3.resource('dynamodb').Table('Proteus2_ETL_LatestBatch')
        response = db_table.query(
            KeyConditionExpression= Key('program').eq("CC_Scheduler"),
            ConsistentRead=True
        )

        lastCCEndDateTime = response['Items'][0]['cc_successful_endintervaldatetime']
        batchId = response['Items'][0]['batchid']
        print("batchId", batchId)
        if(lastCCEndDateTime == ""):
            strCCStartInterval = dtCurrentDateTime - timedelta(minutes=10)
            strCCStartIntervalDateTime = strCCStartInterval.strftime("%m/%d/%Y %H:%M")
        else:
            if lastCCEndDateTime is None or lastCCEndDateTime.lower() == "null" or lastCCEndDateTime.lower() == "none":
                print("IN IFFF")
                print(batchId)
                db_table = boto3.resource('dynamodb')
                client = boto3.client('dynamodb')
                paginator = client.get_paginator('scan')
                
                response = {
                    'TableName': 'Proteus2_ETL_Batch',
                    'FilterExpression': 'batchid = :batchId',
                    'ExpressionAttributeValues':{
                                            ':batchId': {'S' : batchId}}}
                                            
                print(response)
                page_iterator = paginator.paginate(**response)
                for page in page_iterator:
                    if len(page['Items']) != 0:
                        break
               
                response = page
                print(response)
                lastCCEndDateTime = response['Items'][0]['ccendintervaldateTime']['S']
            strCCStartIntervalDateTime = lastCCEndDateTime

        strCCEndInterval = dtCurrentDateTime - timedelta(minutes=5)

        strCCEndIntervalDateTime = strCCEndInterval.strftime("%m/%d/%Y %H:%M")

        print("CC interval: " + strCCStartIntervalDateTime + " to " + strCCEndIntervalDateTime)

        strBatchId = "CC_" + dtCurrentDateTime.strftime("%m%d%y%H%M%S")
        print("BatchID: " + strBatchId)
        strExtractName = "ChangeCapture"
        userId = "schedule"
    

    dtNow = datetime.datetime.now().strftime("%m/%d/%Y %H:%M:%S")
    target_db = os.environ['target_db']
    changes_db = os.environ['changes_db']
    db_creds =  os.environ['db_creds']
	
    db_table = boto3.resource('dynamodb').Table('Proteus2_ETL_Batch')

    response = db_table.put_item(
        Item={
            'batchid': strBatchId,
            'bucketname': i_bucketname,
            'filename': i_filename,
            'filedatetime': strFileDateTime,
            'filepath': i_s3filepath,
            'extract': strExtractName,
            'datecreated': dtNow,
            'processed': False,
            'success': False,
            'usercreated': userId,
            'status': 'NEW',
            'datemodified': dtNow,
            'ccstartintervaldateTime': strCCStartIntervalDateTime,
            'ccendintervaldateTime': strCCEndIntervalDateTime
        }
    )

    # TODO Implement Err Handling
    return {
        'batchid': strBatchId,
        'batchdatetime': dtNow,
        'bucketname': i_bucketname,
        'filename': i_filename,
        'filedatetime': strFileDateTime,
        'filepath': i_s3filepath,
        'extract': strExtractName,
        'usercreated': userId,
        'ccstartintervaldateTime': strCCStartIntervalDateTime,
        'ccendintervaldateTime': strCCEndIntervalDateTime,
        'target_db':target_db,
        'changes_db':changes_db,
        'db_creds':db_creds
    }
