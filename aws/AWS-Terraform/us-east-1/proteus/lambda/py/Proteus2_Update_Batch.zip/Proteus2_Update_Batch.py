import datetime
import boto3
from boto3.dynamodb.conditions import Key
import json

def lambda_handler(event, context):
    print(event)
    i_mode = ""

    try:
        i_batchid = event['batchid']
        i_batchdatetime = event['batchdatetime']
        i_processed = event['batchprocessinfo']['processed']
        i_success = event['batchprocessinfo']['success']
        i_mode = "SCHEDULER"

        try:
            i_status = event['batchprocessinfo']['status']
        except:
            i_status ="SUCCESS"

    except:
        print("INFO: An exception occurred in FMG DW step function. This function is called thro EventBridge error rule.")
        i_status = event['detail']['status']
        i_errinput = event['detail']['input']
        json_object = json.loads(i_errinput)

        i_filedatetime = json_object["time"]
        d = datetime.datetime.strptime(i_filedatetime, "%Y-%m-%dT%H:%M:%SZ")
        strFileDateTime = d.strftime("%m/%d/%Y %H:%M:%S")

        i_batchid = "FILE_" + d.strftime("%m%d%y%H%M%S")

        i_success = False
        i_processed = True
        i_mode = "OTHER"

    # CC (Change Capture) End Date can be read from event input. Commented following on 01/10/2023.
    # Comment start *****************
    #db_table = boto3.resource('dynamodb').Table('Proteus2_ETL_Batch')
    
    #response = db_table.query(
    #    KeyConditionExpression= Key('batchid').eq(i_batchid),
    #    ScanIndexForward= False,
    #    Limit=1,
    #    ConsistentRead=True
    #)
    
    #ccendintervaldateTime = response['Items'][0]['ccendintervaldateTime']
    # Comment End *******************

    print(i_batchid)
    print(i_batchdatetime)

    if(i_status == "SUCCESS" and i_mode == "SCHEDULER"):
        print ("Call from scheduled step function.")
        
        i_ccendintervaldateTime = event['ccendintervaldateTime'] 
        
        if(i_ccendintervaldateTime != "" and i_ccendintervaldateTime != None and i_ccendintervaldateTime != "NULL"):
            print ("End date available.")
            ccendintervaldateTime = i_ccendintervaldateTime
            print (ccendintervaldateTime)
        elif("FILE" in i_batchid):
            print("Here is the code")
            ccendintervaldateTime = i_ccendintervaldateTime								  
        else:
            print("End interval is Null")
            exit(0)


        db_table = boto3.resource('dynamodb').Table('Proteus2_ETL_LatestBatch')

        response = db_table.update_item(
            Key={
                'program': "CC_Scheduler"
            },
            UpdateExpression="set #cc_successful_endintervaldatetime=:cc_successful_endintervaldatetime, #batchid=:batchid",
            ExpressionAttributeValues={
                ':cc_successful_endintervaldatetime':ccendintervaldateTime,
                ':batchid': i_batchid
            },
            ExpressionAttributeNames={
                "#cc_successful_endintervaldatetime" : "cc_successful_endintervaldatetime",
                "#batchid" : "batchid"
            },
            ReturnValues="UPDATED_NEW"
        )
	
											

    dtNow = datetime.datetime.now().strftime("%m/%d/%Y %H:%M:%S")

    db_table = boto3.resource('dynamodb').Table('Proteus2_ETL_Batch')

    response = db_table.update_item(
        Key={
            'batchid': i_batchid,
            'datecreated': i_batchdatetime
        },
        UpdateExpression="set #success=:success, #processed=:processed, #status=:status, #datemodified=:datemodified",
        ExpressionAttributeValues={
            ':success': i_success,
            ':processed':i_processed,
            ':status':i_status,
            ':datemodified':dtNow
        },
        ExpressionAttributeNames={
            "#success" : "success",
            "#processed": "processed",
            "#status": "status",
            "#datemodified": "datemodified"
        },
        ReturnValues="UPDATED_NEW"
    )
	
    print ("Batch Update successful.")
	
    #TODO Implement Err Handling
    return {
        'transaction': 'success'
    }
