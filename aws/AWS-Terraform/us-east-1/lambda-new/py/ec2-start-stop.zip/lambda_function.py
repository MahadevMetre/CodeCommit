#################################################################
## Author 		- Pavan Venkata Charan, Veerla, Modified by sbose
## Purpose      - Start or stop ec2 instances
#################################################################

import boto3
import logging
import os
from datetime import datetime
from botocore.exceptions import ClientError

logger = logging.getLogger()
log_level = logging.getLevelName(os.environ.get('LOG_LEVEL'))
logger.setLevel(log_level)

ec2 = boto3.resource('ec2')
client = boto3.client('ec2')

def lambda_handler(event, context):
    try:
        ec2 = boto3.resource('ec2')
        client = boto3.client('ec2')
        adhoc_Instances = ec2.instances.filter(
            Filters = [
                {'Name': 'tag:Type', 'Values': [event['tagValue']]}
                ]
            )
        now = datetime.now()
        current_date = now.astimezone().strftime("%Y-%m-%d %I:%M %p %Z")
        current_day = now.strftime("%A")
        logger.info("Today is "+current_day+" "+current_date)
        if(current_day == 'Saturday'):
            stop_ec2(adhoc_Instances)
        elif(current_day == 'Monday'):
            start_ec2(adhoc_Instances)
        else:
            logger.info("Today is "+current_day+", Hence no action taken.")
    except Exception as e:
        logger.info(e)

def start_ec2(adhoc_Instances):
    try:
        for instance in adhoc_Instances:
            try:
                adhocInstanceId = instance.id
                response = client.start_instances(InstanceIds=[instance.id], DryRun=False)
                logger.info("Started the instance with instance Id "+adhocInstanceId);
                # email_message="EC2 Instance "+str(adhocInstanceId)+" was auto started by Lambda."
                # send_email(email_message)
            except Exception as e:
                logger.info(e)
                logger.info("Error starting instance "+adhocInstanceId)
    except Exception as e:
        logger.info("Exception occured when starting EC2 instance.")

def stop_ec2(adhoc_Instances):
    try:
        for instance in adhoc_Instances:
            try:
                adhocInstanceId = instance.id
                response = client.stop_instances(InstanceIds=[instance.id], Force=True)
                logger.info("Stopped the instance with instance Id "+adhocInstanceId);
                # email_message="EC2 Instance "+str(adhocInstanceId)+" was auto stopped by Lambda."
                # send_email(email_message)
            except Exception as e:
                logger.info("ERROR INFO: "+e)
                logger.info("Error stopping instance "+adhocInstanceId)
    except Exception as e:
        logger.info("Exception occured when stopping EC2 instance.")

def send_email(email_message):
    SENDER = "aws_lambda_alerts_dev@franklinmadisonds.com"
    RECIPIENT = os.environ.get('NOTIFY_EMAIL')

    AWS_REGION = "us-east-1"

    SUBJECT = "Email From EC2 Auto Start/Stop Lambda"

    # The email body for recipients with non-HTML email clients.
    BODY_TEXT = (email_message)

    # The character encoding for the email.
    CHARSET = "UTF-8"

    # Create a new SES resource and specify a region.
    client = boto3.client('ses',region_name=AWS_REGION)

    # Try to send the email.
    try:
        #Provide the contents of the email.
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    RECIPIENT,
                ],
            },
            Message={
                'Body': {
                    'Text': {
                        'Data': BODY_TEXT
                    },
                },
                'Subject': {
                    'Data': SUBJECT
                },
            },
            Source=SENDER
        )
    # Display an error if something goes wrong.	
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])