const { KMS } = require('@aws-sdk/client-kms');

const { SQS } = require('@aws-sdk/client-sqs');

const { SSM } = require('@aws-sdk/client-ssm');

const INFO = 'INFO';
const DEBUG = 'DEBUG';
const ERROR = 'ERROR';
const GENERIC_ERROR = "Unable to process your request at this time";

async function getParam() {
    try {
        const kms = new KMS();
        const kmsdata = {
            CiphertextBlob: Buffer.from(process.env.BLOB, 'base64')
        };
        const data = await kms.decrypt(kmsdata);
        let result = Buffer.from(data.Plaintext).toString('utf8');
        let ssm = new SSM();
        const singleParam = { Name: result, WithDecryption: true };
        const value = await ssm.getParameter(singleParam);
        const param = JSON.parse(value.Parameter.Value);
         return param;
    } catch (err) {
        logme(GENERIC_ERROR + ":" + err.message, ERROR);
        throw new Error(GENERIC_ERROR);
    }
}
async function postMessage(event, callback, params) {
    let sqs = new SQS({
        "region": params.region
    });
    if (event.request.userAttributes.email && event.triggerSource === "PostConfirmation_ConfirmSignUp") {
        let sqsParams = {
            DelaySeconds: params.delaySecondsSQS,
            MessageBody: JSON.stringify(event, null, 2),
            QueueUrl: params.confirmUserSQS
        };
        sqs.sendMessage(sqsParams, function (err, data) {
            if (err) {
                logme('Unable to process your request: ' + err.message, ERROR);
            } else {
                logme('Posted Message to SQS', INFO);
            }
        });
        // Return to Amazon Cognito
        callback(null, event);
    } else {
        // Nothing to do, the user's email ID is unknown
        callback(null, event);
    }
}
exports.handler = async (event, context, callback) => {
    try {
        //get params from Parameter Store
        let params = await getParam();
        //post message to SQS
        await postMessage(event, callback, params);
    } catch (err) {
        logme('Unable to process your request: ' + err.message, ERROR);
        callback(GENERIC_ERROR, event);
    }
};
let logme = (message, level) => {
    if ((process.env.LOGGER === INFO || process.env.LOGGER === DEBUG) && level === INFO) {
        console.info(message);
    } else if (process.env.LOGGER === DEBUG && level === DEBUG) {
        console.log(message);
    } else if (level === ERROR) {
        console.error(message);
    }
};
