# custom-authorization-lambda
The purpose of this lambda function is to validate the Access Token and generate an IAM policy that tells API Gateway whether the access to the resources should be allowed or denied.
