export const handler = async (event, context, callback) => {
   try{
      console.log(event);
      //let token = getToken(event.authorizationToken);
      
      let policy =  {
        "principalId": "test-123", 
        "policyDocument": {
          "Version": "2012-10-17",
          "Statement": [
            {
              "Action": "execute-api:Invoke",
              "Effect": "Allow",
              "Resource": "arn:aws:execute-api:us-east-1:702230634984:u4xzj2oank/stage/*/*"
            }
          ]
        }
      }
      console.log(JSON.stringify(policy));
      return policy;
   }
   catch(err){
      console.error(err);
      callback("Unauthorized");
   }
};