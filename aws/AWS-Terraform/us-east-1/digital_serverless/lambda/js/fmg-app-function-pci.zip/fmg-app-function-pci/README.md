# create-json-web-token-lambda
The purpose of this lambda function is to create a JWT and sign it using AWS KMS. It also verifies that the client requesting the token is registered in the DynamoDB table.
