import json
import os
import datetime
import boto3
import botocore 
import botocore.session as bc
from botocore.client import Config
import math
from datetime import timedelta, timezone
import dateutil.tz


def lambda_handler(event, context):
    #print(event)
    database = event['database']
    db_creds = event['db_creds']
    upload_date = event['upload_date']
    
    session = boto3.session.Session()
    region = session.region_name
    
    # Initializing Secret Manager's client    
    client = session.client(
            service_name='secretsmanager',
            region_name=region
        )
    
    get_secret_value_response = client.get_secret_value(
            SecretId=db_creds
        )
    secret_arn=get_secret_value_response['ARN']
    
    secret = get_secret_value_response['SecretString']
    secret_json = json.loads(secret)
    
    cluster_id=secret_json['dbClusterIdentifier']
    
    # Initializing Botocore client
    bc_session = bc.get_session()
    
    session1 = boto3.Session(
            botocore_session=bc_session,
            region_name=region
        )
    
    # Initializing Redshift's client   
    config = Config(connect_timeout=5, read_timeout=5)
    
    print("Starting Data Cleanup")
    
    client_redshift = session.client("redshift-data", config = config)

    query_str = "delete from olmb.factonlinematchback where upload_date < '" + upload_date + "';"
    print(query_str)
    
    try:
        result = client_redshift.execute_statement(Database= database, SecretArn= secret_arn, Sql= query_str, ClusterIdentifier= cluster_id)
        print("Deleted")
        #print(result)
        
    except botocore.exceptions.ConnectionError as e:
        client_redshift_1 = session.client("redshift-data", config = config)
        result = client_redshift_1.execute_statement(Database= database, SecretArn= secret_arn, Sql= query_str, ClusterIdentifier= cluster_id)
        print(result)

    except Exception as e:
        return {
        'statusCode': 500
        }
        
    print("Finished Data Cleanup")
    return {
        'statusCode': 200
    }