import json
import os
import datetime
import boto3
import botocore 
import botocore.session as bc
from botocore.client import Config
import math
from datetime import timedelta, timezone
import dateutil.tz


def lambda_handler(event, context):
    #print(event)
    database = os.environ['database']
    db_creds = os.environ['db_creds']
    file_type = ''
    
    bucket_name = event['detail']['bucket']['name']
    filepath = event['detail']['object']['key']
    filedatetime = event['time']
    full_file_path = "s3://" + bucket_name + "/" + filepath

    source_filepath = filepath.rsplit("/", 1)[0]
    source_filename = filepath.rsplit("/", 1)[1]
    i_filedatetime = datetime.datetime.strptime(filedatetime, "%Y-%m-%dT%H:%M:%SZ")
    upload_date = i_filedatetime.strftime("%Y-%m-%d")
    print("upload_date: " + upload_date)
    
    if "MONTHLY" in source_filename:
        file_type = 'MONTHLY'
    else:
        file_type = 'DAILY'
        
    print("file_type: " + file_type)
    return {
        'statusCode': 200,
        'upload_date': upload_date,
        'file_type': file_type,
        'file_path': full_file_path,
        'database': database,
        'db_creds': db_creds
    }