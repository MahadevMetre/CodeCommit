const AWS = require("aws-sdk");
const cognito = new AWS.CognitoIdentityServiceProvider();
var cognitoidentity = new AWS.CognitoIdentity();
const INFO = 'INFO';
const DEBUG = 'DEBUG';
const ERROR = 'ERROR';
const INVALID_INPUT_ERROR = "Invalid refresh token received";
const GENERIC_ERROR = "Unable to process your request at this time";

async function getParam() {
    try {
        const kms = new AWS.KMS();
        const kmsdata = {
            CiphertextBlob: Buffer.from(process.env.BLOB, 'base64')
        };
        const data = await kms.decrypt(
            kmsdata).promise();
        var result = data.Plaintext.toString('utf-8');
        var ssm = new AWS.SSM();
        const singleParam = { Name: result, WithDecryption: true };
        const value = await ssm.getParameter(singleParam).promise();
        const param = JSON.parse(value.Parameter.Value);
        return param;
    } catch (err) {
        logme(GENERIC_ERROR + ":" + err.message, ERROR);
        throw new Error(GENERIC_ERROR);
    }
}
async function refreshToken(event, param) {
    var refreshToken;
    const authFlow = "REFRESH_TOKEN_AUTH";
    const region = param.region;
    const userPoolId = region + "_" + param.userPoolId;
    const clientId = param.clientId;
    const identityPoolId = region + ":" + param.identityPoolId;
    var cognitoidp = "cognito-idp." + region + ".amazonaws.com/" + userPoolId;
    if (event.body !== null && event.body !== undefined) {
        let request_body = JSON.parse(event.body);
        if (request_body.refreshToken === null || request_body.refreshToken === undefined) {
            logme(INVALID_INPUT_ERROR, ERROR);
            throw new Error(INVALID_INPUT_ERROR);
        } else {
            refreshToken = request_body.refreshToken;
            let params = {
                AuthFlow: authFlow,
                ClientId: clientId, // From Cognito dashboard, generated app client id
                UserPoolId: userPoolId,
                AuthParameters: {
                    REFRESH_TOKEN: refreshToken
                }
            };
            try {
                var response = await cognito.adminInitiateAuth(params).promise();
            } catch (err) {
                logme('Exception in Cognito User Pool: ' + err.message, ERROR);
                throw new Error(INVALID_INPUT_ERROR);
            }
            var id_params = {
                IdentityPoolId: identityPoolId, /* required */
                Logins: {
                    [cognitoidp]: response.AuthenticationResult.IdToken
                }
            };
            try {
                var responseId = await cognitoidentity.getId(id_params).promise();
            } catch (err) {
                logme('Exception in Cognito Identity Get Id: ' + err.message, ERROR);
                throw new Error(INVALID_INPUT_ERROR);
            }
            var cred_id_params = {
                IdentityId: responseId.IdentityId, /* required */
                Logins: {
                    [cognitoidp]: response.AuthenticationResult.IdToken
                }
            };
            try {
                var cred_id_response = await cognitoidentity.getCredentialsForIdentity(cred_id_params).promise();
            } catch (err) {
                logme('Exception in Cognito Identity Get Credentials: ' + err.message, ERROR);
                throw new Error(INVALID_INPUT_ERROR);
            }
            var responseBody = {
                accesskey: cred_id_response.Credentials.AccessKeyId,
                secretKey: cred_id_response.Credentials.SecretKey,
                sessionToken: cred_id_response.Credentials.SessionToken
            };
            return JSON.stringify(responseBody);
        }
    } else {
        logme(INVALID_INPUT_ERROR, ERROR);
        throw new Error(INVALID_INPUT_ERROR);
    }
}
exports.handler = async (event, context, callback) => {
    var statusCode = 200;
    var body;
    try {
        //get params from Parameter Store
        var params = await getParam();
        //call Cognito apis to refresh tokens.
        body = await refreshToken(event, params);
    } catch (err) {
        logme('Unable to process your request', ERROR);
        statusCode = 400;
        body = '{"error":"' + err.message + '"}';
    }
    var response = {
        "statusCode": statusCode,
        "body": body
    };
    callback(null, response);
};
var logme = (message, level) => {
    if ((process.env.LOGGER === INFO || process.env.LOGGER === DEBUG) && level === INFO) {
        console.info(message);
    } else if (process.env.LOGGER === DEBUG && level === DEBUG) {
        console.log(message);
    } else if (level === ERROR) {
        console.error(message);
    }
};