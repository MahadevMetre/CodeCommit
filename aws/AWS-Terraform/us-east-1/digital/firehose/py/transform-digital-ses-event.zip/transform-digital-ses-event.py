import base64

import json
import datetime
import boto3
from datetime import timedelta, timezone
import dateutil.tz
from boto3.dynamodb.conditions import Key
import time
import os

print('Loading function')

def lambda_handler(event, context):
    output = []
    encoded_payload = ''

    for record in event['records']:
        print(record['recordId'])
        payload = base64.b64decode(record['data']).decode('utf-8')
        #print('pre-encoded:' + payload)
        
        processedPayload = payload.replace("ses:source-tls-version","sourcetlsversion").replace("ses:configuration-set","configurationset").replace("ses:operation","operation").replace("ses:recipient-isp","recipientisp").replace("ses:source-ip","sourceip").replace("ses:from-domain","fromdomain").replace("ses:sender-identity","senderidentity").replace("ses:caller-identity","calleridentity").replace("ses:outgoing-ip","outgoingip")
        output_record = {
            'recordId': record['recordId'],
            'result': 'Ok',
            'data': base64.b64encode(processedPayload.encode('utf-8')).decode('utf-8')
        }
        output.append(output_record)
        
        #Write to S3
        
        encoded_payload = encoded_payload + processedPayload
        #print('encoded:' + encoded_payload)
        
    bucket_name = os.environ.get('bucket_name')
    file_name = "SES_" + str(round(time.time() * 1000)) + ".json"
    s3_path_prefix = os.environ.get('s3_prefix')
    s3_path = s3_path_prefix + file_name
    
    s3 = boto3.resource("s3")
    s3.Bucket(bucket_name).put_object(Key=s3_path, Body=encoded_payload.encode("utf-8"))

    print('Successfully processed {} records.'.format(len(event['records'])))

    return {'records': output}
    
    
