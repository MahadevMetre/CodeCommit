import json
import os
import urllib3

def invoke_url(api_url, event_id):
    timeout = urllib3.Timeout(connect=0.1, read=0.1)
    http = urllib3.PoolManager(timeout=timeout)
    encoded_body = json.dumps({
        "eventId": event_id
    })
    try:
        print("Invoking URL: {}.".format(api_url))
        http.request('POST', api_url, headers={'Content-Type': 'application/json'}, body=encoded_body)
    except Exception as e:
        print("Exception : ", e)
    else:
        pass

def lambda_handler(event, context):
    # Get the event details
    event_id = event['id'] # Unique event id
    event_source = event['source'] # Source of the event
    print("Event ID: {}, Event Source: {}".format(event_id, event_source))

    # Exit if not invoked from scheduler
    if event_source != "aws.scheduler":
        print("Validation failed for event source: {}.".format(event_source))
        print("Exiting the process.")
        exit(1)

    invoke_url(os.environ.get('EMAIL_API_URL'), event_id)
    invoke_url(os.environ.get('PREVIEW_EMAIL_API_URL'), event_id)

    return {
        'statusCode': 200,
        'body': json.dumps('Execution completed')
    }