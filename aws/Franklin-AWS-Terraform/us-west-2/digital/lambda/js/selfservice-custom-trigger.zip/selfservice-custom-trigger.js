const fs = require('fs');
const https = require('https');

const INFO = 'INFO';
const DEBUG = 'DEBUG';
const ERROR = 'ERROR';


exports.handler = async (event, context, callback) => {
     if (event.triggerSource === "CustomMessage_SignUp") {
         await signup(event);
     } else if (event.triggerSource === "CustomMessage_ForgotPassword") {
         await forgotpwd(event);
     } else if (event.triggerSource === "CustomMessage_UpdateUserAttribute") {
         await updateEmail(event);
     } else if (event.triggerSource === "CustomMessage_VerifyUserAttribute") {
         await verifyEmail(event);
     }

    if (!(event.response.emailSubject === null)) {
	    callAtlasUpdateApi(event);
    }
     // Return success
     console.info("Main EVENT\n" + JSON.stringify(event, null, 2))
     callback(null,event);
    
};

var callAtlasUpdateApi = (event) => {
	
	logme("Coverage Data:" + JSON.stringify(event.request.userAttributes['custom:coverageId']), DEBUG);
    var request_data = {
        coverageId: event.request.userAttributes['custom:coverageId'],
        emailId: event.request.userAttributes.email,
        subject: event.response.emailSubject
    };
    let response_data = '';
    logme("Request Data:" + JSON.stringify(request_data), DEBUG);
    // the post options
    var optionspost = {
        host: process.env.HOST,
        port: process.env.PORT,
        path: '/digitalserviceweb/v1/selfservice/updateAtlas',
        method: 'POST',
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
    };
    
    logme("Options Data:" + JSON.stringify(optionspost), DEBUG);
    var error;
    var error_message;
    try {
        let reqPost = https.request(optionspost, function (res) {
            logme("Response StatusCode: " + res.statusCode, DEBUG);
            res.on('data', function (chunk) {
                response_data += chunk;
            });
            res.on('end', function () {
                logme("Response Received: ", response_data.toString(), DEBUG);
                if (res.statusCode === 200) {
                    response_data = JSON.parse(response_data.toString());
                    if (response_data.status === 0) {
                        logme("Error Received from Response: " + response_data, ERROR);
                        // error from response
                        error_message = response_data.errors[0].errorMessage;
                        // set error
                        error = new Error(error_message);
                       
                    }
                }
            });
            // handle the possible errors
            res.on('error', function () {
                logme("Response Error: " + response_data.toString(), ERROR);
                error_message = 'Unable to process your request';
                // set error
                error = new Error(error_message);
                
            });
        });
        //do the request
        reqPost.write(JSON.stringify(request_data));
        //finish the request
        reqPost.end();
    } catch (err) {
        // Handle the error safely
        logme("Function Error: " + err, ERROR);
        error_message = 'Unable to process your request';
        // set error
        error = new Error(error_message);
        //callback(error, event);
    }

};

var signup = async (event) => {
    logme("Inside CustomMessage_SignUp Trigger", INFO);

    // Ensure that your message contains event.request.codeParameter. This is the placeholder for code that will be sent
    const { codeParameter } = event.request;
    const { userName } = event;
    const url = process.env.LOGIN_URL;
    const link = `${url}?confirm_user=true&user_name=${userName}&confirmation_code=${codeParameter}`;
	logme("Codeparameter : " + codeParameter, DEBUG);
	logme("Link : " + link, DEBUG);
    event.response.emailSubject = "Verify my email";
    var body = fs.readFileSync("verification_email.html").toString('utf8');
    body = body.replace('${link}', link).replace('${registerlink}', process.env.REGISTRATION_URL);
    event.response.emailMessage = body;

    logme("Constructed SignUp Email : " + event.request.userAttributes.email, DEBUG);
    logme("Exiting CustomMessage_SignUp Trigger", INFO);
};


var forgotpwd = async (event) => {
    var body;
    logme("Inside CustomMessage_ForgotPassword Trigger", INFO);

    // Ensure that your message contains event.request.codeParameter. This is the placeholder for code that will be sent
    const { codeParameter } = event.request;
    const { userName } = event;
    const url = process.env.RESET_PASSWORD_URL;
    const contactUs = process.env.CONTACT_US;
    const link = `${url}?userId=${userName}&confirmationCode=${codeParameter}`;
    event.response.emailSubject = "Reset your password";
    body = fs.readFileSync("forgot_password.html").toString('utf8');
    body = body.replace('${passwordresetlink}', link).replace('${contactuslink}', contactUs);
    event.response.emailMessage = body;

    logme("Exiting CustomMessage_ForgotPassword Trigger", INFO);
};

var updateEmail = async (event) => {
    var body;
    logme("Inside CustomMessage_UpdateUserAttribute Trigger", INFO);

    // Ensure that your message contains event.request.codeParameter. This is the placeholder for code that will be sent
    const { codeParameter } = event.request;
    event.response.emailSubject = "Update my email";
    body = fs.readFileSync("update_email.html").toString('utf8');
    body = body.replace('${confirmationcode}', codeParameter).replace('${loginlink}', process.env.LOGIN_URL);
    event.response.emailMessage = body;
    
    logme("Exiting CustomMessage_UpdateUserAttribute Trigger", INFO);
};

var verifyEmail = async (event) => {
    var body;
    logme("Inside CustomMessage_VerifyUserAttribute Trigger", INFO);

    // Ensure that your message contains event.request.codeParameter. This is the placeholder for code that will be sent
    const { codeParameter } = event.request;
    event.response.emailSubject = "Verify my email";
    body = fs.readFileSync("resend_verification_code_email.html").toString('utf8');
    body = body.replace('${confirmationcode}', codeParameter);
    event.response.emailMessage = body;

    logme("Exiting CustomMessage_VerifyUserAttribute Trigger", INFO);
};

var logme = (message, level) => {
    if ((process.env.LOGGER === INFO || process.env.LOGGER === DEBUG) && level === INFO) {
        console.info(message);
    } else if (process.env.LOGGER === DEBUG && level === DEBUG) {
        console.log(message);
    } else if (level === ERROR) {
        console.error(message);
    }
};