import json
import os
import urllib3

def lambda_handler(event, context):
    # Get the event details
    event_id = event['id'] # Unique event id
    event_source = event['source'] # Source of the event
    print("Event ID: {}, Event Source: {}".format(event_id, event_source))

    # Set the api url and payload
    if event_source == "aws.scheduler":
        api_url = os.environ.get('ADDRESS_CORRECTION_URL')
        # Set payload
        encoded_body = json.dumps({
            "eventId": event_id
        })
    else:
        print("Validation failed for event source: {}.".format(event_source))
        print("Exiting the process.")
        exit(1)

    http = urllib3.PoolManager()
    response = http.request('POST', api_url,
                    headers={'Content-Type': 'application/json'},
                    body=encoded_body)
    print("API URL: {}".format(api_url))
    print("Response from API: {}".format(response.data.decode('utf-8')))
    return {
        'statusCode': 200,
        'body': json.dumps('Execution completed')
    }