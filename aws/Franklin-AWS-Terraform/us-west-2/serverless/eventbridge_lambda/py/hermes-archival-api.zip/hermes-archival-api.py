import json
import os
import urllib3

def lambda_handler(event, context):
    # Assign default values for the variables
    event_id = event_source = bucket_name = object_key = event_type = "default"

    # Get the event details
    event_id = event['id'] # Unique event id
    event_source = event['source'] # Source of the event
    bucket_name = event['detail']['bucket']['name'] # Name of the bucket
    object_key = event['detail']['object']['key'] # File path
    event_type = event['detail']['reason'] # S3 action which triggered the event
    print("Event ID: {}, Event Source: {}, Bucket Name: {}, Object Key: {}, Event Type: {}".format(event_id, event_source, bucket_name, object_key, event_type))

    # Get the environment variable values
    # Exit if event source is not s3 or filename does not end with .json
    if event_source != os.environ.get('EVENT_SOURCE') or os.environ.get('OBJECT_SUFFIX') not in object_key:
        print("Validation failed for event source: {} or object suffix: {}.".format(event_source, object_key))
        print("Exiting the process.")
        exit(1)

    # Set the api url
    api_url = os.environ.get('ARCHIVAL_API_URL')

    # Preparing the POST request data
    encoded_body = json.dumps({
            "eventId": event_id,
            "bucketName": bucket_name,
            "objectKey": object_key
        })

    http = urllib3.PoolManager()
    response = http.request('POST', api_url,
                    headers={'Content-Type': 'application/json'},
                    body=encoded_body)
    print("API URL: {}".format(api_url))
    print("Response from API: {}".format(response.data.decode('utf-8')))
    return {
        'statusCode': 200,
        'body': json.dumps('Execution completed')
    }