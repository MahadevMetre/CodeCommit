import json
import os
import random
import time
import urllib3

def invoke_url(api_url, event_id, bucket_name, object_key):
    timeout = urllib3.Timeout(connect=0.1, read=0.1)
    http = urllib3.PoolManager(timeout=timeout)
    encoded_body = json.dumps({
        "eventId": event_id,
        "bucketName": bucket_name,
        "objectKey": object_key
    })
    try:
        print("Invoking URL: {}.".format(api_url))
        http.request('POST', api_url, headers={'Content-Type': 'application/json'}, body=encoded_body)
    except Exception as e:
        print("Exception : ", e)
    else:
        pass

def lambda_handler(event, context):
    # Assign default values for the variables
    event_id = event_source = bucket_name = object_key = event_type = "default"

    # Get the event details
    event_id = event['id'] # Unique event id
    event_source = event['source'] # Source of the event
    bucket_name = event['detail']['bucket']['name'] # Name of the bucket
    object_key = event['detail']['object']['key'] # File path
    event_type = event['detail']['reason'] # S3 action which triggered the event
    print("Event ID: {}, Event Source: {}, Bucket Name: {}, Object Key: {}, Event Type: {}".format(event_id, event_source, bucket_name, object_key, event_type))

    # Exit if not invoked from s3
    if event_source != "aws.s3":
        print("Validation failed for event source: {}.".format(event_source))
        print("Exiting the process.")
        exit(1)

    # Exit if the object key is not in valid file paths
    valid_file_paths_str = os.environ.get('VALID_FILE_PATHS')
    valid_file_paths = [item for item in valid_file_paths_str.split(",") if item]
    validFilePath = False
    if any(file_path in object_key for file_path in valid_file_paths):
        validFilePath = True
    if not validFilePath:
        print("Validation failed for object key: {}.".format(object_key))
        print("Ensure the object key path is added in VALID_FILE_PATHS environment variable.")
        print("Exiting the process.")
        exit(1)

    # Exit if the object extention is not in valid file extentions
    valid_file_extns_str = os.environ.get('VALID_FILE_EXTENTIONS')
    valid_file_extns = [item for item in valid_file_extns_str.split(",") if item]
    _, object_extention = os.path.splitext(object_key)
    if object_extention not in valid_file_extns:
        print("Validation failed for object extention: {}.".format(object_extention))
        print("Ensure the object extention is added in VALID_FILE_EXTENTIONS environment variable.")
        print("Exiting the process.")
        exit(1)

    MIN_DELAY = os.environ.get('MIN_DELAY')
    MAX_DELAY = os.environ.get('MAX_DELAY')
    delay = random.randint(int(MIN_DELAY), int(MAX_DELAY))
    print("Sleeping for {} seconds.".format(delay))
    time.sleep(delay)
    invoke_url(os.environ.get('API_URL'), event_id, bucket_name, object_key)

    return {
        'statusCode': 200,
        'body': json.dumps('Execution completed')
    }