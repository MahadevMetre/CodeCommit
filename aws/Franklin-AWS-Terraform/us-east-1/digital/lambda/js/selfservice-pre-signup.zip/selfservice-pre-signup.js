const https = require('https');
const INFO = 'INFO';
const DEBUG = 'DEBUG';
const ERROR = 'ERROR';

exports.handler = (event, context, callback) => {
    var request_data = {
        firstName: event.request.userAttributes.given_name,
        lastName: event.request.userAttributes.family_name,
        coverageId: event.request.userAttributes['custom:coverageId'],
        emailId: event.request.userAttributes.email,
        phoneNumber: event.request.userAttributes.phone_number
    };
    let response_data = '';
    logme("Request Data:" + JSON.stringify(request_data), DEBUG);
    // the post options
    var optionspost = {
        host: process.env.HOST,
        port: process.env.PORT,
        path: '/digitalserviceweb/v1/selfservice/validatecustomer',
        method: 'POST',
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
    };
    var error;
    var error_message;
    try {
        let reqPost = https.request(optionspost, function (res) {
            logme("Response StatusCode: " + res.statusCode, INFO);
            res.on('data', function (chunk) {
                response_data += chunk;
            });
            res.on('end', function () {
                logme("Response Received: ", response_data.toString(), DEBUG);
                if (res.statusCode === 200) {
                    response_data = JSON.parse(response_data.toString());
                    if (response_data.status === 0) {
                        logme("Error Received from Response: " + response_data.errors[0].errorMessage, ERROR);
                        // error from response
                        error_message = response_data.errors[0].errorMessage;
                        // set error
                        error = new Error(error_message);
                        callback(error, event);
                    } else {
                        callback(null, event);
                    }
                }
            });
            // handle the possible errors
            res.on('error', function () {
                logme("Response Error: " + response_data.toString(), ERROR);
                error_message = 'Unable to process your request';
                // set error
                error = new Error(error_message);
                callback(error, event);
            });
        });
        //do the request
        reqPost.write(JSON.stringify(request_data));
        //finish the request
        reqPost.end();
    } catch (err) {
        // Handle the error safely
        logme("Function Error: " + err, ERROR);
        error_message = 'Unable to process your request';
        // set error
        error = new Error(error_message);
        callback(error, event);
    }
};
var logme = (message, level) => {
    if ((process.env.LOGGER === INFO || process.env.LOGGER === DEBUG) && level === INFO) {
        console.info(message);
    } else if (process.env.LOGGER === DEBUG && level === DEBUG) {
        console.log(message);
    } else if (level === ERROR) {
        console.error(message);
    }
};