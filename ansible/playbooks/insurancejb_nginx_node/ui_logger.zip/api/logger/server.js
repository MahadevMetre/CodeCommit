const express = require('express');
const log4js = require('log4js');

log4js.configure({
  appenders: {
    logappender: { type: 'dateFile', filename: '/common/logs/insurancejb/insurancejbs2/AtlasUI.log', pattern: '.yyyy-MM-dd-hh', compress: true }
  },
  categories: {
    default: { appenders: [ 'logappender' ], level: 'debug'}
  }
});
const app = express();
app.use(express.json());

 
//READ Request Handlers
app.get('/', (req, res) => {
const logger = log4js.getLogger('logappender');
logger.info('api reached');


	res.send('Welcome to API');
});
 
app.get('/api/logger', (req,res)=> {
 
const logger = log4js.getLogger('logappender');
logger.info(req);

res.send('Welcome to API');
});

 
//CREATE Request Handler
app.post('/api/logger', (req, res)=> {

const logger = log4js.getLogger('logappender');

if(req.body.level == 5){		
	logger.error('messgae : ' + req.body.message + ' file name : ' + req.body.fileName + ' line number : ' + req.body.lineNumber + ' timestamp : ' + req.body.timestamp);
}
else
{
	logger.info('messgae : ' + req.body.message + ' file name : ' + req.body.fileName + ' line number : ' + req.body.lineNumber + ' timestamp : ' + req.body.timestamp);
}

res.send('Success');
});
  
//PORT ENVIRONMENT VARIABLE
const port = process.env.PORT || 3000;
app.listen(port, () => console.log('Listening on port ${port}..'));